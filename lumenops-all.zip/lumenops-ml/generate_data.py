"""Creates SYNTHETIC complaints for the demo (not real BESCOM data).

Run:  python generate_data.py   -> writes sample_complaints.json and critical_sites.json
Three fault zones (A big + hospital, B medium, C small) plus a few lone complaints.
"""
import json
import random
from datetime import datetime, timedelta, timezone

BASE = datetime(2026, 11, 18, 10, 0, tzinfo=timezone.utc)  # pretend "now" is 13:00

ZONES = [
    # name, centre lat, centre lng, reports, spread (deg), start offset (min), span (min)
    ("A", 12.9250, 77.5830, 42, 0.0012, 0, 150),
    ("B", 12.9690, 77.7500, 11, 0.0010, 120, 40),
    ("C", 13.0350, 77.5970, 3, 0.0006, 160, 15),
]
LONERS = [(12.9100, 77.6400, 170), (13.0000, 77.5500, 175)]

CRITICAL_SITES = [
    {"name": "Sample Hospital", "type": "hospital", "lat": 12.9254, "lng": 77.5836},
    {"name": "Sample Water Pumping Station", "type": "water_pumping", "lat": 13.0600, "lng": 77.5900},
]


def generate():
    rng = random.Random(7)  # fixed seed: same data on every call, so the demo is repeatable
    complaints = []
    n = 1
    for _, lat, lng, count, spread, start, span in ZONES:
        for _ in range(count):
            t = BASE + timedelta(minutes=start + rng.uniform(0, span))
            complaints.append({
                "id": f"C{n:03d}",
                "lat": round(lat + rng.uniform(-spread, spread), 6),
                "lng": round(lng + rng.uniform(-spread, spread), 6),
                "timestamp": t.isoformat(),
            })
            n += 1
    for lat, lng, minute in LONERS:
        complaints.append({
            "id": f"C{n:03d}", "lat": lat, "lng": lng,
            "timestamp": (BASE + timedelta(minutes=minute)).isoformat(),
        })
        n += 1
    return complaints


if __name__ == "__main__":
    with open("sample_complaints.json", "w") as f:
        json.dump(generate(), f, indent=2)
    with open("critical_sites.json", "w") as f:
        json.dump(CRITICAL_SITES, f, indent=2)
    print("wrote sample_complaints.json and critical_sites.json")
