"""LumenOps ML engine: groups duplicate complaints into incidents and scores priority.

Two steps:
1. DBSCAN groups complaints that are close in place AND time (same probable fault).
2. A weighted score ranks each incident (reports, duration, critical load).
"""
from datetime import datetime
import math

import numpy as np
from sklearn.cluster import DBSCAN

DEFAULT_PARAMS = {
    "eps_m": 250,            # complaints within ~250 m can belong to one fault
    "time_window_min": 90,   # ...and within ~90 minutes of each other
    "min_samples": 2,        # at least 2 complaints make a cluster
    "critical_radius_m": 300,
    "reports_cap": 30,       # reports at which the "reports" part is maxed out
    "duration_cap_min": 180, # duration at which the "duration" part is maxed out
    "w_reports": 0.4,        # w1
    "w_duration": 0.3,       # w2
    "w_critical": 0.3,       # w3
    "high_at": 55,           # score >= 55  -> High
    "medium_at": 20,         # score >= 20  -> Medium, else Low
}


def _parse_time(value):
    return datetime.fromisoformat(str(value).replace("Z", "+00:00"))


def _to_meters(lat, lng, lat0, lng0):
    """Rough flat-earth conversion, fine for city-scale distances."""
    x = (lng - lng0) * 111_320 * math.cos(math.radians(lat0))
    y = (lat - lat0) * 110_540
    return x, y


def _distance_m(lat1, lng1, lat2, lng2):
    x, y = _to_meters(lat2, lng2, lat1, lng1)
    return math.hypot(x, y)


def analyze(complaints, critical_sites=None, now=None, params=None):
    """complaints: list of {id, lat, lng, timestamp}. Returns incidents sorted by priority."""
    p = {**DEFAULT_PARAMS, **(params or {})}
    critical_sites = critical_sites or []
    if not complaints:
        return {"incidents": [], "summary": {"complaints": 0, "incidents": 0}}

    times = [_parse_time(c["timestamp"]) for c in complaints]
    t0 = min(times)
    now_dt = _parse_time(now) if now else max(times)

    lat0 = float(np.mean([c["lat"] for c in complaints]))
    lng0 = float(np.mean([c["lng"] for c in complaints]))

    # Features: x (m), y (m), time scaled so that time_window_min ~ eps_m metres.
    scale = p["eps_m"] / p["time_window_min"]
    feats = []
    for c, t in zip(complaints, times):
        x, y = _to_meters(c["lat"], c["lng"], lat0, lng0)
        minutes = (t - t0).total_seconds() / 60
        feats.append([x, y, minutes * scale])
    labels = DBSCAN(eps=p["eps_m"], min_samples=p["min_samples"]).fit_predict(np.array(feats))

    # Lone complaints (label -1) become their own single-report incident.
    next_label = (labels.max() + 1) if len(labels) else 0
    groups = {}
    for idx, lab in enumerate(labels):
        if lab == -1:
            lab = next_label
            next_label += 1
        groups.setdefault(int(lab), []).append(idx)

    incidents = []
    for members in groups.values():
        lat = float(np.mean([complaints[i]["lat"] for i in members]))
        lng = float(np.mean([complaints[i]["lng"] for i in members]))
        first = min(times[i] for i in members)
        last = max(times[i] for i in members)
        reports = len(members)
        duration_min = max(0.0, (now_dt - first).total_seconds() / 60)

        nearby = []
        for s in critical_sites:
            if _distance_m(lat, lng, s["lat"], s["lng"]) <= p["critical_radius_m"]:
                nearby.append({"name": s.get("name", "Critical site"), "type": s.get("type", "critical")})

        reports_part = min(reports / p["reports_cap"], 1.0)
        duration_part = min(duration_min / p["duration_cap_min"], 1.0)
        critical_part = 1.0 if nearby else 0.0
        score = 100 * (p["w_reports"] * reports_part
                       + p["w_duration"] * duration_part
                       + p["w_critical"] * critical_part)
        level = "High" if score >= p["high_at"] else "Medium" if score >= p["medium_at"] else "Low"

        incidents.append({
            "lat": round(lat, 6),
            "lng": round(lng, 6),
            "reports": reports,
            "complaint_ids": [complaints[i]["id"] for i in members],
            "first_reported": first.isoformat(),
            "last_reported": last.isoformat(),
            "duration_min": round(duration_min, 1),
            "critical_nearby": nearby,
            "score": round(score, 1),
            "priority": level,
            # Explainability: how each factor contributed (shown in the dashboard)
            "breakdown": {
                "reports": round(100 * p["w_reports"] * reports_part, 1),
                "duration": round(100 * p["w_duration"] * duration_part, 1),
                "critical_load": round(100 * p["w_critical"] * critical_part, 1),
            },
        })

    incidents.sort(key=lambda i: i["score"], reverse=True)
    for n, inc in enumerate(incidents, start=1):
        inc["id"] = f"INC-{n:03d}"
        inc["rank"] = n

    return {
        "incidents": incidents,
        "summary": {
            "complaints": len(complaints),
            "incidents": len(incidents),
            "merged_duplicates": len(complaints) - len(incidents),
            "high": sum(i["priority"] == "High" for i in incidents),
            "medium": sum(i["priority"] == "Medium" for i in incidents),
            "low": sum(i["priority"] == "Low" for i in incidents),
        },
        "params_used": p,
    }
