# LumenOps ML service (Flask)

Groups duplicate outage complaints into incidents (DBSCAN) and ranks them with a priority score.
All data here is synthetic. Replace it with real complaints from your Node API.

## Run
```
pip install -r requirements.txt
python generate_data.py     # optional: writes sample JSON files
python app.py               # http://localhost:5001
python -c "import test_engine as t; t.test_engine_groups_and_ranks(); t.test_api(); print('tests passed')"   # quick self-test
```
Try it: open http://localhost:5001/demo in the browser.

## API
`POST /analyze`
```json
{
  "complaints": [{"id": "C001", "lat": 12.925, "lng": 77.583, "timestamp": "2026-11-18T10:05:00+00:00"}],
  "critical_sites": [{"name": "Sample Hospital", "type": "hospital", "lat": 12.9254, "lng": 77.5836}],
  "now": "2026-11-18T13:00:00+00:00",
  "params": {"eps_m": 250}
}
```
`critical_sites`, `now` and `params` are optional. If `now` is missing, the latest complaint time is used.

Response: `incidents` (sorted, rank 1 = most urgent), each with `id, rank, lat, lng, reports, complaint_ids,
first_reported, duration_min, critical_nearby, score, priority (High/Medium/Low), breakdown`, plus a `summary`.

## How the score works (matches slide 5)
```
score = 100 x ( 0.4 x min(reports/30, 1) + 0.3 x min(duration/180 min, 1) + 0.3 x critical_site_within_300m )
High >= 55, Medium >= 20, otherwise Low
```
`breakdown` shows how many points each factor added, so the dashboard can explain every ranking.
Reports are used as a stand-in for consumers affected. All numbers are in DEFAULT_PARAMS in engine.py.

## Calling it from Node (Express)
```js
const r = await fetch("http://localhost:5001/analyze", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ complaints, critical_sites })
});
const { incidents, summary } = await r.json();
```

## Things to know before the demo
- Clustering uses place AND time: 250 m and 90 min by default. If clusters merge too much or too little, change `eps_m` and `time_window_min`.
- A lone complaint stays as its own incident with 1 report.
- Weights and thresholds are our own starting values, not BESCOM's. Say that if asked.
