from app import app
from engine import analyze
from generate_data import CRITICAL_SITES, generate


def test_engine_groups_and_ranks():
    out = analyze(generate(), CRITICAL_SITES)
    inc = out["incidents"]
    assert out["summary"]["complaints"] == 58
    assert out["summary"]["incidents"] == 5          # A, B, C + 2 lone complaints
    assert [i["reports"] for i in inc][:3] == [42, 11, 3]
    assert [i["priority"] for i in inc][:3] == ["High", "Medium", "Low"]
    assert inc[0]["critical_nearby"][0]["type"] == "hospital"
    assert inc[0]["rank"] == 1 and inc[0]["id"] == "INC-001"


def test_api():
    client = app.test_client()
    assert client.get("/health").json == {"status": "ok"}
    r = client.get("/demo")
    assert r.status_code == 200 and r.json["incidents"][0]["priority"] == "High"
    body = {"complaints": generate(), "critical_sites": CRITICAL_SITES}
    r = client.post("/analyze", json=body)
    assert r.status_code == 200 and r.json["summary"]["incidents"] == 5
    assert client.post("/analyze", json={"complaints": [{"id": "x"}]}).status_code == 400
    assert client.post("/analyze", json={}).status_code == 400
    assert analyze([])["incidents"] == []
