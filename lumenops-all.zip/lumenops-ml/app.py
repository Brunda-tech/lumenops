"""Flask ML service for LumenOps.

Run:  python app.py        (listens on http://localhost:5001)

POST /analyze   body: {"complaints":[...], "critical_sites":[...], "now": "...", "params": {...}}
GET  /demo      runs the engine on the built-in synthetic data
GET  /health
"""
from flask import Flask, jsonify, request

from engine import analyze
from generate_data import CRITICAL_SITES, generate

app = Flask(__name__)


@app.after_request
def allow_cors(resp):
    # Simple CORS so the React app can call this service while developing.
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/analyze", methods=["POST", "OPTIONS"])
def analyze_route():
    if request.method == "OPTIONS":
        return "", 204
    body = request.get_json(silent=True) or {}
    complaints = body.get("complaints")
    if not isinstance(complaints, list):
        return jsonify({"error": "'complaints' must be a list"}), 400
    for c in complaints:
        if not all(k in c for k in ("id", "lat", "lng", "timestamp")):
            return jsonify({"error": "each complaint needs id, lat, lng, timestamp"}), 400
    try:
        result = analyze(complaints, body.get("critical_sites"), body.get("now"), body.get("params"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify(result)


@app.route("/demo")
def demo():
    return jsonify(analyze(generate(), CRITICAL_SITES))


if __name__ == "__main__":
    app.run(port=5001, debug=True)
