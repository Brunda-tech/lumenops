# LumenOps: how to run everything

Four folders, run in this order (four terminals). Node 22.13+ and Python 3 are needed.

1. `lumenops-ml`: `pip install -r requirements.txt`, then `python app.py` (port 5001)
2. `lumenops-api`: set your own staff passwords, then `npm start` (port 4000). See its README for the exact command on Windows, Mac and Linux.
3. `lumenops-dashboard`: `npm install`, then `npm run dev` (port 5173). Staff sign in here.
4. `lumenops-consumer`: `npm install`, then `npm run dev` (port 5174). The public page.

## Demo story
1. Consumer app: report an outage (use "Enter location another way" and a demo spot if there is no GPS).
2. Dashboard as **admin**: load the demo complaints, assign a crew to the incident.
3. Dashboard as **supervisor**: check the work, choose the cause, mark it completed.
4. Consumer app: the status page moves from Reported to Crew assigned to Restored by itself.
Extras: "My bill" (sample account RR-DEMO-1042, code 0042, sandbox payment), "New connection" (admin approves on the dashboard).

## The demo page (works without installing anything)
`lumenops-live-demo.html` opens in any browser, even offline. It is a click-through simulation with sample data and an English / Kannada switch.
Demo sign-ins: admin / Admin@demo1 and supervisor / Super@demo1. Use it as a backup if something breaks on the day.
The Kannada text was written by an AI and has not been checked by a native speaker, so have someone read it before you present.
It is only a simulation: it is not connected to the four projects, and the real apps are English only.

## Before you present
- Run `npm install` for both React apps today. It could not be tested in the build environment, and neither could the real map (Leaflet).
- Choose your own staff passwords. Do not use the ones in any test or example.
- Bills, payments, DTLMS-style data and the SMS are sandbox or sample. Say so clearly.
- Tests: `npm test` in `lumenops-api` (17 tests) and `python -c "import test_engine as t; t.test_engine_groups_and_ranks(); t.test_api()"` in `lumenops-ml`.
