import { useState } from "react";
import { createApplication, getApplication } from "../api.js";
import { parseCoord, parsePhone } from "../utils.js";

export default function ApplicationPanel() {
  const [f, setF] = useState({ name: "", address: "", type: "Domestic", load: "3", phone: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState(null);
  const [ref, setRef] = useState("");
  const [last4, setLast4] = useState("");
  const [status, setStatus] = useState(null);
  const [statusError, setStatusError] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setError("");
    const phone = parsePhone(f.phone);
    const kw = parseCoord(f.load, 0.1, 50);
    if (!f.name.trim() || !f.address.trim()) return setError("Please enter your name and address.");
    if (kw === null) return setError("Enter a load between 0.1 and 50 kW.");
    if (!phone) return setError("Enter a valid phone number (10 to 13 digits).");
    setBusy(true);
    try {
      const res = await createApplication({ name: f.name.trim(), address: f.address.trim(), type: f.type, load_kw: kw, phone });
      setCreated({ ref: res.ref, last4: phone.slice(-4) });
      setRef(res.ref);
      setLast4(phone.slice(-4));
      setStatus(null);
    } catch (err) {
      setError(err.message);
    }
    setBusy(false);
  }

  async function check(e) {
    e.preventDefault();
    setStatusError("");
    setStatus(null);
    try {
      setStatus(await getApplication(ref.trim().toUpperCase(), last4.trim()));
    } catch (err) {
      setStatusError(err.message);
    }
  }

  return (
    <div>
      <form onSubmit={submit} className="block" noValidate>
        <h2>Apply for a new connection</h2>
        <p className="note">Demo form. Documents are not uploaded in this demo.</p>
        <label>Full name<input value={f.name} onChange={set("name")} autoComplete="name" /></label>
        <label>Address<input value={f.address} onChange={set("address")} autoComplete="street-address" /></label>
        <label>
          Connection type
          <select value={f.type} onChange={set("type")}><option>Domestic</option><option>Commercial</option></select>
        </label>
        <label>Required load (kW)<input value={f.load} onChange={set("load")} inputMode="decimal" /></label>
        <label>Phone number<input value={f.phone} onChange={set("phone")} type="tel" inputMode="tel" autoComplete="tel" /></label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" type="submit" disabled={busy}>{busy ? "Sending..." : "Submit application"}</button>
        {created && (
          <p className="loc-ok" role="status">
            Application received. Your reference is <b>{created.ref}</b>. Keep it: you need it and the last 4 digits of your phone ({created.last4}) to check the status.
          </p>
        )}
      </form>

      <form onSubmit={check} className="block lookup">
        <h2>Check an application</h2>
        <label>Reference<input value={ref} onChange={(e) => setRef(e.target.value)} placeholder="APP-0001" autoCapitalize="characters" /></label>
        <label>Last 4 digits of the phone<input value={last4} onChange={(e) => setLast4(e.target.value)} inputMode="numeric" maxLength={4} /></label>
        <button className="secondary" type="submit" disabled={!ref.trim() || last4.length !== 4}>Check status</button>
        {statusError && <p className="error" role="alert">{statusError}</p>}
        {status && (
          <p className="message" role="status">
            {status.ref}: <b className={status.status === "Approved" ? "ok" : status.status === "Rejected" ? "bad" : ""}>{status.status}</b>
            {status.review_note ? " - " + status.review_note : ""}
          </p>
        )}
      </form>
    </div>
  );
}
