import { useState } from "react";
import { createComplaint } from "../api.js";
import { DEMO_SPOTS, TYPES, jitter, parseCoord, parsePhone, round6 } from "../utils.js";

const GEO_ERRORS = {
  1: "Location permission was denied. Allow location access, or choose another option below.",
  2: "Your location is not available right now. Choose another option below.",
  3: "Finding your location took too long. Try again or choose another option below.",
};

export default function ReportForm({ onSubmitted }) {
  const [location, setLocation] = useState(null); // { lat, lng, accuracy?, source }
  const [locLoading, setLocLoading] = useState(false);
  const [locError, setLocError] = useState("");
  const [manualLat, setManualLat] = useState("");
  const [manualLng, setManualLng] = useState("");
  const [type, setType] = useState("no_power");
  const [phone, setPhone] = useState("");
  const [consent, setConsent] = useState(false);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  function detect() {
    setLocError("");
    if (!("geolocation" in navigator)) {
      setLocError("This device cannot detect your location. Choose another option below.");
      return;
    }
    setLocLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({
          lat: round6(pos.coords.latitude),
          lng: round6(pos.coords.longitude),
          accuracy: Math.round(pos.coords.accuracy),
          source: "gps",
        });
        setLocLoading(false);
      },
      (err) => {
        let msg = GEO_ERRORS[err.code] || "Could not get your location.";
        if (!window.isSecureContext) msg += " (Location detection only works on https or localhost.)";
        setLocError(msg);
        setLocLoading(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  }

  function onManual(latStr, lngStr) {
    setManualLat(latStr);
    setManualLng(lngStr);
    const lat = parseCoord(latStr, -90, 90);
    const lng = parseCoord(lngStr, -180, 180);
    if (lat !== null && lng !== null) {
      setLocation({ lat, lng, source: "manual" });
      setLocError("");
    } else if (location && location.source === "manual") {
      setLocation(null);
    }
  }

  function onDemo(id) {
    const spot = DEMO_SPOTS.find((s) => s.id === id);
    if (!spot) return;
    setLocation({ lat: jitter(spot.lat), lng: jitter(spot.lng), source: "demo" });
    setLocError("");
  }

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!location) {
      setError("Please set your location first.");
      return;
    }
    let phoneDigits = null;
    if (phone.trim()) {
      phoneDigits = parsePhone(phone);
      if (!phoneDigits) {
        setError("Enter a valid phone number (10 to 13 digits), or leave it empty.");
        return;
      }
      if (!consent) {
        setError("Please tick the box to receive SMS updates, or clear the phone number.");
        return;
      }
    }
    const payload = { lat: location.lat, lng: location.lng, type };
    if (phoneDigits) payload.phone = phoneDigits;
    if (note.trim()) payload.note = note.trim();

    setSubmitting(true);
    try {
      const res = await createComplaint(payload);
      onSubmitted(res.id);
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={submit} noValidate>
      <section className="block">
        <h2>1. Where is the problem?</h2>
        <button type="button" className="secondary" onClick={detect} disabled={locLoading}>
          {locLoading ? "Finding your location..." : "Use my current location"}
        </button>

        {location && (
          <p className="loc-ok" role="status">
            Location set ({location.source === "gps" ? "detected" : location.source === "manual" ? "entered by you" : "demo spot"}):
            {" "}{location.lat}, {location.lng}
            {location.accuracy ? ` (accurate to about ${location.accuracy} m)` : ""}
            {" "}
            <a href={`https://www.openstreetmap.org/?mlat=${location.lat}&mlon=${location.lng}#map=17/${location.lat}/${location.lng}`} target="_blank" rel="noreferrer">
              View on map
            </a>
          </p>
        )}
        {locError && <p className="error" role="alert">{locError}</p>}

        <details className="more">
          <summary>Enter location another way</summary>
          <div className="row">
            <label>
              Latitude
              <input inputMode="decimal" value={manualLat} placeholder="12.9716" onChange={(e) => onManual(e.target.value, manualLng)} />
            </label>
            <label>
              Longitude
              <input inputMode="decimal" value={manualLng} placeholder="77.5946" onChange={(e) => onManual(manualLat, e.target.value)} />
            </label>
          </div>
          <label>
            Demo spots (for testing without GPS)
            <select defaultValue="" onChange={(e) => onDemo(e.target.value)}>
              <option value="" disabled>Choose a demo spot</option>
              {DEMO_SPOTS.map((s) => (
                <option key={s.id} value={s.id}>{s.label}</option>
              ))}
            </select>
          </label>
        </details>
      </section>

      <section className="block">
        <h2>2. What is happening?</h2>
        <div className="types" role="radiogroup" aria-label="Type of problem">
          {TYPES.map((t) => (
            <label key={t.value} className={"type " + (type === t.value ? "on" : "")}>
              <input type="radio" name="type" value={t.value} checked={type === t.value} onChange={() => setType(t.value)} />
              {t.label}
            </label>
          ))}
        </div>
        <label>
          Note (optional)
          <textarea rows={3} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Anything that helps, for example: whole street is dark" />
          <span className="count">{note.length}/300</span>
        </label>
      </section>

      <section className="block">
        <h2>3. Get SMS updates (optional)</h2>
        <label>
          Phone number
          <input type="tel" inputMode="tel" autoComplete="tel" value={phone} placeholder="98765 43210" onChange={(e) => setPhone(e.target.value)} />
        </label>
        {phone.trim() && (
          <label className="check">
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            I agree to receive SMS updates about this complaint. My number is used only for this.
          </label>
        )}
      </section>

      {error && <p className="error" role="alert">{error}</p>}

      <button type="submit" className="primary" disabled={submitting || !location}>
        {submitting ? "Sending..." : "Report outage"}
      </button>
      {!location && <p className="hint">Set your location to enable the button.</p>}
    </form>
  );
}
