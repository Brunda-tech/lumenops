import { useCallback, useEffect, useState } from "react";
import { EVENTS_URL, POLL_MS, getComplaint } from "../api.js";
import { formatTime, saveRef } from "../utils.js";

const STEPS = ["Reported", "Crew assigned", "Restored"];
const STEP_INDEX = { Pending: 0, "Crew assigned": 1, Restored: 2 };

const MESSAGES = {
  Pending: "We have received your report. The control room will review it.",
  "Crew assigned": "A crew has been assigned to your area.",
  Restored: "Power has been reported restored in your area. If it is still out, please report again.",
};

export default function StatusTracker({ initialRef, onReportAgain }) {
  const [input, setInput] = useState(initialRef || "");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [stale, setStale] = useState(false);

  const load = useCallback(async (ref, quiet) => {
    if (!quiet) setLoading(true);
    try {
      const d = await getComplaint(ref);
      setData(d);
      setError("");
      setStale(false);
      saveRef(d.id);
    } catch (err) {
      if (quiet) {
        setStale(true); // keep showing the last known status
      } else {
        setData(null);
        setError(err.status === 404 ? "We could not find that reference. Check the code and try again." : err.message);
      }
    } finally {
      if (!quiet) setLoading(false);
    }
  }, []);

  // Load the remembered complaint when the page opens.
  useEffect(() => {
    if (initialRef) load(initialRef, false);
  }, [initialRef, load]);

  // Refresh automatically until power is restored.
  const id = data ? data.id : null;
  const status = data ? data.status : null;
  useEffect(() => {
    if (!id || status === "Restored") return undefined;
    const timer = setInterval(() => load(id, true), POLL_MS);
    return () => clearInterval(timer);
  }, [id, status, load]);

  // Update straight away when the control room changes something (falls back to the timer above).
  useEffect(() => {
    if (!id || status === "Restored" || typeof EventSource === "undefined") return undefined;
    const es = new EventSource(EVENTS_URL);
    es.addEventListener("incidents-changed", () => load(id, true));
    return () => es.close();
  }, [id, status, load]);

  function lookup(e) {
    e.preventDefault();
    const ref = input.trim().toUpperCase();
    if (!ref) return;
    setInput(ref);
    load(ref, false);
  }

  const stepIdx = data ? STEP_INDEX[data.status] ?? 0 : 0;
  const others = data && data.incident ? data.incident.reports - 1 : 0;

  return (
    <div>
      <form onSubmit={lookup} className="lookup">
        <label>
          Complaint reference
          <input value={input} placeholder="C0001" onChange={(e) => setInput(e.target.value)} autoCapitalize="characters" />
        </label>
        <button type="submit" className="secondary" disabled={loading}>
          {loading ? "Checking..." : "Check status"}
        </button>
      </form>

      {error && <p className="error" role="alert">{error}</p>}

      {data && (
        <section className="block status-card" aria-live="polite">
          <div className="ref">Reference <strong>{data.id}</strong></div>
          <div className="when">Reported {formatTime(data.timestamp)}</div>

          <ol className="steps">
            {STEPS.map((label, i) => {
              const done = i <= stepIdx;
              const current = !done && i === stepIdx + 1;
              return (
                <li key={label} className={(done ? "done " : "") + (current ? "current" : "")}>
                  <span className="dot">{done ? "\u2713" : i + 1}</span>
                  <span className="label">{label}</span>
                </li>
              );
            })}
          </ol>

          <p className="message">{MESSAGES[data.status] || MESSAGES.Pending}</p>
          {others > 0 && (
            <p className="group">
              Your report is grouped with {others} other {others === 1 ? "report" : "reports"} in your area.
            </p>
          )}
          {stale && <p className="hint">Could not refresh just now. Showing the last known status.</p>}

          {data.status === "Restored" ? (
            <button className="primary" onClick={onReportAgain}>Still no power? Report again</button>
          ) : (
            <p className="hint">This page updates by itself.</p>
          )}
        </section>
      )}
    </div>
  );
}
