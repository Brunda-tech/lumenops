import { useEffect } from "react";

// Decorative artwork: pylons, power lines, transformers and a city skyline, with "current" moving along the lines.
// It is drawn with plain SVG (no image files) and sits behind the page.
export function Scene() {
  useEffect(() => {
    // People who ask their device to reduce motion get a still picture.
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      document.querySelectorAll(".bg animateMotion, .bg animate").forEach((n) => n.remove());
    }
  }, []);
  const lines = [
    "M168 294Q270 332 372 294", "M156 329Q270 367 384 329", "M468 294Q570 332 672 294",
    "M456 329Q570 367 684 329", "M768 294Q870 332 972 294", "M756 329Q870 367 984 329",
  ];
  const winks = [[30, 425, 3], [95, 390, 4], [620, 405, 3.5], [1095, 420, 2.8]];
  return (
    <>
      <svg className="hid" aria-hidden="true">
        <defs>
          <symbol id="py" viewBox="0 0 100 220">
            <g fill="none" stroke="currentColor" strokeWidth="3" strokeLinejoin="round">
              <path d="M28 218L46 30H54L72 218M36 160H64M41 112H59M44 70H56M30 150L62 112M70 150L38 112M36 112L56 70M64 112L44 70M10 48H90M20 78H80M10 48V56M90 48V56M20 78V86M80 78V86" />
            </g>
          </symbol>
          <symbol id="tr" viewBox="0 0 70 120">
            <g fill="none" stroke="currentColor" strokeWidth="3" strokeLinejoin="round">
              <path d="M35 118V70M6 18H64" />
              <rect x="14" y="42" width="42" height="40" rx="6" />
              <path d="M22 42V82M30 42V82M38 42V82M46 42V82M16 36H54M18 10V18M35 10V18M52 10V18M12 8H24M29 8H41M46 8H58" />
            </g>
          </symbol>
        </defs>
      </svg>
      <div className="bg" aria-hidden="true">
        <svg viewBox="0 0 1200 500" preserveAspectRatio="xMidYMax slice">
          <g style={{ color: "var(--sc)" }} opacity=".2" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M0 497H1200" strokeWidth="3" />
            <g fill="currentColor" stroke="none" opacity=".5">
              <rect x="20" y="410" width="50" height="87" /><rect x="82" y="370" width="38" height="127" />
              <rect x="540" y="420" width="60" height="77" /><rect x="610" y="385" width="36" height="112" />
              <rect x="1080" y="400" width="55" height="97" /><rect x="1142" y="430" width="40" height="67" />
            </g>
            {[60, 360, 660, 960].map((x) => <use key={x} href="#py" x={x} y="237" width="120" height="260" />)}
            <use href="#tr" x="262" y="401" width="52" height="96" />
            <use href="#tr" x="842" y="401" width="52" height="96" />
            <path d={lines.join("")} />
          </g>
          <g fill="#f5a524" opacity=".85">
            {lines.map((d, i) => (
              <circle key={d} r="3.5"><animateMotion dur={[5, 6.5, 5.5, 7, 6, 5][i] + "s"} repeatCount="indefinite" path={d} /></circle>
            ))}
            {winks.map(([x, y, dur], i) => (
              <rect key={x} x={x} y={y} width="6" height="6">
                <animate attributeName="opacity" values={i % 2 ? "1;0;1" : "0;1;0"} dur={dur + "s"} repeatCount="indefinite" />
              </rect>
            ))}
          </g>
        </svg>
      </div>
    </>
  );
}

// A small picture for the top of a page: pylon, transformer with a flashing bolt, and a lit house.
export function Hero() {
  return (
    <svg className="hero" viewBox="0 0 400 170" aria-hidden="true">
      <path d="M10 160H390" stroke="currentColor" strokeWidth="3" />
      <use href="#py" x="10" y="40" width="80" height="120" />
      <use href="#tr" x="170" y="50" width="60" height="110" />
      <path d="M330 160V120L350 105L370 120V160Z" fill="none" stroke="currentColor" strokeWidth="3" />
      <path d="M82 66Q128 92 175 66M225 66Q300 72 350 105" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M200 6L190 30H199L194 50L212 24H203Z" fill="#f5a524"><animate attributeName="opacity" values="1;.25;1" dur="1.6s" repeatCount="indefinite" /></path>
      <rect x="343" y="128" width="14" height="14" fill="#f5a524"><animate attributeName="opacity" values=".35;1;.35" dur="2.4s" repeatCount="indefinite" /></rect>
      <g fill="#f5a524">
        <circle r="3.5"><animateMotion dur="3s" repeatCount="indefinite" path="M82 66Q128 92 175 66" /></circle>
        <circle r="3.5"><animateMotion dur="4s" repeatCount="indefinite" path="M225 66Q300 72 350 105" /></circle>
      </g>
    </svg>
  );
}
