import { useState } from "react";
import { consumerLogin, getBill, payBill } from "../api.js";

const METHODS = ["UPI", "Card", "Net banking"];
const monthName = (m) => new Date(m + "-01T00:00:00Z").toLocaleString("en-IN", { month: "short", year: "numeric", timeZone: "UTC" });

export default function BillPanel() {
  const [token, setToken] = useState("");
  const [rr, setRr] = useState("");
  const [code, setCode] = useState("");
  const [data, setData] = useState(null);
  const [method, setMethod] = useState("UPI");
  const [receipt, setReceipt] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function reset(message = "") {
    setToken("");
    setData(null);
    setReceipt(null);
    setError(message);
  }

  async function signIn(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await consumerLogin(rr.trim(), code.trim());
      setData(await getBill(res.token));
      setToken(res.token);
      setCode("");
    } catch (err) {
      setError(err.message);
    }
    setBusy(false);
  }

  async function pay() {
    setError("");
    setBusy(true);
    try {
      setReceipt(await payBill(token, method));
      setData(await getBill(token));
    } catch (err) {
      if (err.status === 401) reset("Your session ended. Please sign in again.");
      else setError(err.message);
    }
    setBusy(false);
  }

  if (!token || !data) {
    return (
      <form onSubmit={signIn} className="block">
        <h2>View and pay your bill</h2>
        <p className="note">Demo with sample data. Try the sample account: RR-DEMO-1042 and code 0042.</p>
        <label>
          RR number
          <input value={rr} onChange={(e) => setRr(e.target.value)} placeholder="RR-DEMO-1042" autoCapitalize="characters" />
        </label>
        <label>
          Last 4 digits of your registered phone
          <input value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric" maxLength={4} placeholder="0042" />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" type="submit" disabled={busy || !rr.trim() || code.length !== 4}>
          {busy ? "Checking..." : "Show my bill"}
        </button>
      </form>
    );
  }

  const bills = data.bills;
  const current = bills[0];
  const max = Math.max(...bills.map((b) => b.units), 1);
  const history = [...bills].reverse();

  return (
    <div>
      <section className="block">
        <h2>{current ? monthName(current.month) : "Bill"}</h2>
        <p className="note">{data.note}</p>
        <div className="who">{data.account.name} &middot; {data.account.rr}</div>
        {current && (
          <>
            <div className="amount">&#8377;{current.amount}</div>
            <div className="m">{current.units} units &middot; due {current.due_date} &middot; <b className={current.status === "Paid" ? "ok" : "bad"}>{current.status}</b></div>
          </>
        )}
        {receipt && (
          <p className="loc-ok" role="status">
            {receipt.message} Receipt {receipt.receipt}, &#8377;{receipt.amount} by {receipt.method}.
          </p>
        )}
        {current && current.status === "Unpaid" && (
          <>
            <label>
              Pay with (sandbox)
              <select value={method} onChange={(e) => setMethod(e.target.value)}>
                {METHODS.map((m) => <option key={m}>{m}</option>)}
              </select>
            </label>
            {error && <p className="error" role="alert">{error}</p>}
            <button className="primary" onClick={pay} disabled={busy}>{busy ? "Working..." : `Pay \u20B9${current.amount} (demo)`}</button>
          </>
        )}
      </section>

      <section className="block">
        <h2>Usage, last {bills.length} months</h2>
        <div className="bars">
          {history.map((b) => (
            <div key={b.id} style={{ height: (b.units / max) * 100 + "%" }}><span>{b.units}</span></div>
          ))}
        </div>
        <div className="mons">{history.map((b) => <span key={b.id}>{monthName(b.month).split(" ")[0]}</span>)}</div>
        <table className="tbl">
          <thead><tr><th>Month</th><th>Units</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
            {bills.map((b) => (
              <tr key={b.id}>
                <td>{monthName(b.month)}</td><td>{b.units}</td><td>&#8377;{b.amount}</td>
                <td className={b.status === "Paid" ? "ok" : "bad"}>{b.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
      <button className="secondary" onClick={() => reset()}>Sign out of bill</button>
    </div>
  );
}
