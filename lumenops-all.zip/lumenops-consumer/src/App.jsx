import { useState } from "react";
import ReportForm from "./components/ReportForm.jsx";
import StatusTracker from "./components/StatusTracker.jsx";
import { Scene, Hero } from "./components/Scene.jsx";
import BillPanel from "./components/BillPanel.jsx";
import ApplicationPanel from "./components/ApplicationPanel.jsx";
import { loadRef, saveRef } from "./utils.js";

export default function App() {
  const [view, setView] = useState("report");
  const [ref, setRef] = useState(loadRef);

  const handleSubmitted = (id) => {
    saveRef(id);
    setRef(id);
    setView("status");
  };

  return (
    <>
    <Scene />
    <div className="shell">
      <header className="head">
        <Hero />
        <h1><span className="bolt">&#9889;</span> LumenOps</h1>
        <p>Report a power outage</p>
      </header>

      <nav className="tabs" role="tablist">
        <button role="tab" aria-selected={view === "report"} className={view === "report" ? "active" : ""} onClick={() => setView("report")}>
          Report outage
        </button>
        <button role="tab" aria-selected={view === "status"} className={view === "status" ? "active" : ""} onClick={() => setView("status")}>
          Check status
        </button>
        <button role="tab" aria-selected={view === "bill"} className={view === "bill" ? "active" : ""} onClick={() => setView("bill")}>
          My bill
        </button>
        <button role="tab" aria-selected={view === "connection"} className={view === "connection" ? "active" : ""} onClick={() => setView("connection")}>
          New connection
        </button>
      </nav>

      <main>
        {view === "report" && <ReportForm onSubmitted={handleSubmitted} />}
        {view === "status" && <StatusTracker key={ref} initialRef={ref} onReportAgain={() => setView("report")} />}
        {view === "bill" && <BillPanel />}
        {view === "connection" && <ApplicationPanel />}
      </main>
    </div>
    </>
  );
}
