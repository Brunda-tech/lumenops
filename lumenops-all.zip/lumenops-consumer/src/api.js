// The API is expected on port 4000 of the same machine that served this page.
const BASE = import.meta.env.VITE_API_BASE || `http://${window.location.hostname}:4000`;

// How often the status page refreshes (milliseconds).
export const POLL_MS = Number(import.meta.env.VITE_POLL_MS) || 10000;

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, options) {
  let res;
  try {
    res = await fetch(BASE + path, options);
  } catch {
    throw new ApiError("Cannot reach the server. Check your connection and try again.", 0);
  }
  let body = null;
  try {
    body = await res.json();
  } catch {
    /* no JSON body */
  }
  if (!res.ok) throw new ApiError((body && body.error) || "Something went wrong (HTTP " + res.status + ").", res.status);
  return body;
}

export const createComplaint = (payload) =>
  request("/api/complaints", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

// Live updates: the API pushes an event whenever something changes.
export const EVENTS_URL = BASE + "/api/events";

const JSON_HEADERS = { "Content-Type": "application/json" };
const bearer = (token) => ({ Authorization: "Bearer " + token });

// Bill (sandbox). The token only lives in the page's memory.
export const consumerLogin = (rr, last4) =>
  request("/api/consumer/login", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ rr, last4 }) });
export const getBill = (token) => request("/api/consumer/bill", { headers: bearer(token) });
export const payBill = (token, method) =>
  request("/api/consumer/pay", { method: "POST", headers: { ...JSON_HEADERS, ...bearer(token) }, body: JSON.stringify({ method }) });

// New connection applications.
export const createApplication = (payload) =>
  request("/api/applications", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify(payload) });
export const getApplication = (ref, last4) =>
  request("/api/applications/" + encodeURIComponent(ref) + "?last4=" + encodeURIComponent(last4));

export const getComplaint = (ref) => request("/api/complaints/" + encodeURIComponent(ref));
