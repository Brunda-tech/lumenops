export const TYPES = [
  { value: "no_power", label: "No power" },
  { value: "partial", label: "Partial power" },
  { value: "low_voltage", label: "Low voltage" },
];

// Shortcuts for testing without GPS. They match the demo data area (see lumenops-ml/generate_data.py).
export const DEMO_SPOTS = [
  { id: "a", label: "Demo spot A (near the sample hospital)", lat: 12.925, lng: 77.583 },
  { id: "b", label: "Demo spot B", lat: 12.969, lng: 77.75 },
  { id: "c", label: "Demo spot C", lat: 13.035, lng: 77.597 },
];

export const round6 = (v) => Math.round(v * 1e6) / 1e6;

// A small random shift (about 40 m) so repeated demo reports are different but still close together.
export const jitter = (v) => round6(v + (Math.random() - 0.5) * 0.0008);

// Same rule as the API: 10 to 13 digits, spaces, + and - are ignored.
export function parsePhone(input) {
  const digits = input.replace(/[\s+-]/g, "");
  return /^\d{10,13}$/.test(digits) ? digits : null;
}

export function parseCoord(value, min, max) {
  if (value.trim() === "") return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
}

export function formatTime(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

// Remember the last complaint so the status page still works after a refresh.
const KEY = "lumenops_last_ref";
export function loadRef() {
  try {
    return localStorage.getItem(KEY) || "";
  } catch {
    return "";
  }
}
export function saveRef(ref) {
  try {
    localStorage.setItem(KEY, ref);
  } catch {
    /* storage not available, ignore */
  }
}
