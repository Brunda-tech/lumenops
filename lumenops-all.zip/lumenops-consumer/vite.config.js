import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// host: true lets a phone on the same Wi-Fi open the page using your laptop's IP address.
export default defineConfig({
  plugins: [react()],
  server: { host: true, port: 5174 },
});
