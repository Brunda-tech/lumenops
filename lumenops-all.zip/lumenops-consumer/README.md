# LumenOps Consumer App (React + Vite)

The page a consumer uses to report an outage and follow its status. Works on a phone or a laptop.

## Run
```
# the ML service (port 5001) and the Node API (port 4000) must be running first, see their READMEs
npm install
npm run dev          # http://localhost:5174
```
The app calls the API on port 4000 of the same machine that served the page. To change that, copy `.env.example` to `.env`.

## What it does
**Report outage**
1. Location: "Use my current location" (GPS), or enter latitude and longitude, or pick a demo spot (for testing without GPS)
2. Type of problem (no power, partial power, low voltage) and an optional note
3. Optional phone number for SMS updates. The number is only sent if the person ticks the consent box

**Check status**
- Shows the complaint reference (for example C0059), the steps Reported, Crew assigned, Restored, and a short message
- Tells the consumer how many other reports were grouped with theirs
- Updates by itself within a second or two when the control room changes the status (live updates from the API), with a 10 second refresh as backup
- Remembers the last reference on that device, and any reference can be looked up
- After "Restored" there is a "Still no power? Report again" button

**My bill** (sandbox)
- Sign in with the RR number and the last 4 digits of the registered phone. Sample account: **RR-DEMO-1042, code 0042**.
- Shows this month's bill, a usage chart and the last 6 months. "Pay" is a **demo**: it gives a receipt but no money moves.
- The usage, amounts and tariff are made up and are not BESCOM's real rates. The bill sign-in lives only in the page and ends when you leave it.

**New connection**
- Name, address, connection type, load (kW) and phone. You get a reference like APP-0001.
- Check the status with the reference and the last 4 digits of the phone. An admin approves or rejects it on the dashboard.
- Documents are not uploaded in this demo.

## Using it on a phone (for the demo)
1. Phone and laptop on the same Wi-Fi. Run `npm run dev` and open `http://<laptop-ip>:5174` on the phone. Allow incoming connections for ports 5174 and 4000 in your laptop firewall.
2. **GPS will not work over plain http on a phone.** Browsers only allow location on https or localhost. On the phone use "Enter location another way" (coordinates or a demo spot), or test GPS on the laptop at `http://localhost:5174`.

## Limits (be honest about these)
- It is a normal web page, not an installable app (no offline mode, no push notifications).
- Reporting needs no login. A complaint's status page shows only its status, never the location, note or phone number. The bill check (RR number + 4 digits) is weak; a real app would send an OTP.
- The "Demo spots" option is only for testing. Remove it from `ReportForm.jsx` before any real use.
- There is no estimated restoration time, because the system has no data to base one on.
- The API has no spam or rate limiting yet.

## Look
The background pictures (pylons, power lines, transformers, a skyline with moving "current") are plain SVG drawn in `src/components/Scene.jsx`, so there are no image files to load.
They and the animations switch off for people whose device asks for reduced motion.

## Files
`src/App.jsx` tabs, `src/api.js` calls to the API, `src/utils.js` helpers, `src/components/ReportForm.jsx`,
`src/components/StatusTracker.jsx`, `src/styles.css`.
