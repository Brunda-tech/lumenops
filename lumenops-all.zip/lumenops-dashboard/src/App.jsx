import { useCallback, useEffect, useMemo, useState } from "react";
import {
  EVENTS_URL, assignCrew, completeIncident, fetchCrews, fetchIncidents, fetchMetrics, reopenIncident,
  session, setToken,
} from "./api.js";
import Login from "./components/Login.jsx";
import { Scene } from "./components/Scene.jsx";
import SummaryCards from "./components/SummaryCards.jsx";
import MetricsBar from "./components/MetricsBar.jsx";
import IncidentMap from "./components/IncidentMap.jsx";
import IncidentQueue from "./components/IncidentQueue.jsx";
import ApplicationsPanel from "./components/ApplicationsPanel.jsx";
import ActivityPanel from "./components/ActivityPanel.jsx";

function Dashboard({ user, onLogout, onAuthError }) {
  const isAdmin = user.role === "admin";
  const [tab, setTab] = useState("incidents");
  const [data, setData] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [crewInfo, setCrewInfo] = useState({ crews: [], causes: [] });
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [loading, setLoading] = useState(true);
  const [updatedAt, setUpdatedAt] = useState(null);
  const [live, setLive] = useState(false);
  const [priorityFilter, setPriorityFilter] = useState("All");
  // Admin starts on incidents that need a crew, supervisor on incidents with a crew assigned.
  const [statusFilter, setStatusFilter] = useState(isAdmin ? "Pending" : "Crew assigned");
  const [selectedId, setSelectedId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [inc, met] = await Promise.all([fetchIncidents(), fetchMetrics()]);
      setData(inc);
      setMetrics(met);
      setError("");
      setUpdatedAt(new Date());
    } catch (err) {
      if (err.status === 401) return onAuthError();
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [onAuthError]);

  useEffect(() => {
    load();
    fetchCrews().then(setCrewInfo).catch((err) => err.status === 401 && onAuthError());
  }, [load, onAuthError]);

  // Live updates (Server-Sent Events). The events carry no data, so we fetch with our login.
  useEffect(() => {
    if (typeof EventSource === "undefined") return undefined;
    const es = new EventSource(EVENTS_URL);
    let timer = null;
    let wasDown = false;
    es.addEventListener("hello", () => {
      setLive(true);
      if (wasDown) {
        wasDown = false;
        load();
      }
    });
    es.addEventListener("incidents-changed", () => {
      clearTimeout(timer);
      timer = setTimeout(load, 250);
    });
    es.onerror = () => {
      wasDown = true;
      setLive(false);
    };
    return () => {
      clearTimeout(timer);
      es.close();
    };
  }, [load]);

  const incidents = data ? data.incidents : [];
  const visible = useMemo(
    () => incidents.filter((i) => (priorityFilter === "All" || i.priority === priorityFilter) && (statusFilter === "All" || i.status === statusFilter)),
    [incidents, priorityFilter, statusFilter]
  );
  const statuses = useMemo(() => Object.fromEntries(incidents.map((i) => [i.id, i.status])), [incidents]);
  const handleSelect = useCallback((id) => setSelectedId(id), []);

  const run = useCallback(
    async (fn) => {
      try {
        await fn();
        setActionError("");
        await load();
      } catch (err) {
        if (err.status === 401) onAuthError();
        else setActionError(err.message);
      }
    },
    [load, onAuthError]
  );

  return (
    <div className="app">
      <header className="top">
        <div>
          <h1><span className="bolt">&#9889;</span> LumenOps</h1>
          <p className="sub">Control Room</p>
        </div>
        <div className="top-right">
          <span className="role-chip">{user.role === "admin" ? "Admin" : "Supervisor"}</span>
          {live && <span className="source live">&#9679; Live updates</span>}
          <button className="refresh" onClick={load} disabled={loading}>{loading ? "Loading..." : "Refresh"}</button>
          {updatedAt && <span className="updated">Updated {updatedAt.toLocaleTimeString("en-IN")}</span>}
          <button className="link" onClick={onLogout}>Sign out</button>
        </div>
      </header>

      {isAdmin && (
        <nav className="tabs">
          {[["incidents", "Incidents"], ["apps", "Connection requests"], ["log", "Activity log"]].map(([k, label]) => (
            <button key={k} className={tab === k ? "active" : ""} onClick={() => setTab(k)}>{label}</button>
          ))}
        </nav>
      )}

      {error && <div className="banner">Could not load incidents ({error}). Check that the Node API and the ML service are running.</div>}
      {actionError && <div className="banner">Could not complete that action: {actionError}</div>}

      {tab === "apps" && isAdmin && <ApplicationsPanel onAuthError={onAuthError} />}
      {tab === "log" && isAdmin && <ActivityPanel onAuthError={onAuthError} />}

      {tab === "incidents" && data && (
        <>
          <SummaryCards summary={data.summary || {}} incidents={incidents} />
          <MetricsBar metrics={metrics} />
          <main className="main">
            <IncidentMap incidents={visible} selectedId={selectedId} onSelect={handleSelect} statuses={statuses} />
            <IncidentQueue
              incidents={visible}
              selectedId={selectedId}
              onSelect={handleSelect}
              role={user.role}
              crews={crewInfo.crews}
              causes={crewInfo.causes}
              onAssign={(inc, crew) => run(() => assignCrew(inc.complaint_ids, crew))}
              onComplete={(inc, cause, note) => run(() => completeIncident(inc.complaint_ids, cause, note))}
              onReopen={(inc) => run(() => reopenIncident(inc.complaint_ids))}
              priorityFilter={priorityFilter}
              onPriorityFilter={setPriorityFilter}
              statusFilter={statusFilter}
              onStatusFilter={setStatusFilter}
            />
          </main>
        </>
      )}
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(() => session.load());
  const [notice, setNotice] = useState("");

  const logout = useCallback((message = "") => {
    setToken("");
    session.clear();
    setUser(null);
    setNotice(typeof message === "string" ? message : "");
  }, []);
  const onAuthError = useCallback(() => logout("Your session ended. Please sign in again."), [logout]);

  if (!user) {
    return (
      <>
      <Scene />
      <Login
        notice={notice}
        onLogin={(u) => {
          setToken(u.token);
          session.save(u);
          setNotice("");
          setUser(u);
        }}
      />
      </>
    );
  }
  return (
    <>
      <Scene />
      <Dashboard key={user.username} user={user} onLogout={() => logout()} onAuthError={onAuthError} />
    </>
  );
}
