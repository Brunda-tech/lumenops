import { useState } from "react";
import { login } from "../api.js";
import { Hero } from "./Scene.jsx";

export default function Login({ onLogin, notice }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await login(username.trim(), password);
      onLogin({ token: res.token, username: res.username, role: res.role });
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  }

  return (
    <div className="login-wrap">
      <form className="login" onSubmit={submit}>
        <Hero />
        <h1><span className="bolt">&#9889;</span> LumenOps</h1>
        <p className="sub">Staff sign in (admin or supervisor)</p>
        {notice && <div className="banner">{notice}</div>}
        <label>
          Username
          <input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" autoFocus />
        </label>
        <label>
          Password
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        </label>
        {error && <p className="error" role="alert">{error}</p>}
        <button className="primary" type="submit" disabled={busy || !username || !password}>
          {busy ? "Signing in..." : "Sign in"}
        </button>
        <p className="hint">
          The accounts are created when the API starts (see the API README). Consumers do not need to sign in here.
        </p>
      </form>
    </div>
  );
}
