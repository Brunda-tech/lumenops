import { useCallback, useEffect, useState } from "react";
import { fetchApplications, reviewApplication } from "../api.js";
import { formatTime } from "../utils.js";

export default function ApplicationsPanel({ onAuthError }) {
  const [apps, setApps] = useState(null);
  const [error, setError] = useState("");
  const [notes, setNotes] = useState({});

  const load = useCallback(async () => {
    try {
      setApps((await fetchApplications()).applications);
      setError("");
    } catch (err) {
      if (err.status === 401) onAuthError();
      else setError(err.message);
    }
  }, [onAuthError]);

  useEffect(() => {
    load();
  }, [load]);

  async function review(ref, decision) {
    try {
      await reviewApplication(ref, decision, (notes[ref] || "").trim() || undefined);
      await load();
    } catch (err) {
      if (err.status === 401) onAuthError();
      else setError(err.message);
    }
  }

  return (
    <section className="panel">
      <div className="panel-head">
        <h2>New connection requests</h2>
        <button className="refresh" onClick={load}>Refresh</button>
      </div>
      {error && <div className="banner">{error}</div>}
      {apps && apps.length === 0 && <p className="empty">No applications yet.</p>}
      {(apps || []).map((a) => (
        <div key={a.ref} className="app-card">
          <div className="item-top">
            <strong>{a.ref}</strong>
            <span className={"status " + (a.status === "Approved" ? "restored" : a.status === "Rejected" ? "rejected" : "")}>{a.status}</span>
            <span className="score">{formatTime(a.created_at)}</span>
          </div>
          <div>{a.name} &middot; {a.type} &middot; {a.load_kw} kW</div>
          <div className="m">{a.address} &middot; phone {a.phone}</div>
          {a.status === "Submitted" ? (
            <div className="act col">
              <input placeholder="Note for the applicant (optional)" maxLength={300} value={notes[a.ref] || ""} onChange={(e) => setNotes({ ...notes, [a.ref]: e.target.value })} />
              <div className="act">
                <button className="action solid" onClick={() => review(a.ref, "Approved")}>Approve</button>
                <button className="action" onClick={() => review(a.ref, "Rejected")}>Reject</button>
              </div>
            </div>
          ) : (
            <div className="m">Reviewed by {a.reviewed_by}{a.review_note ? " · " + a.review_note : ""}</div>
          )}
        </div>
      ))}
    </section>
  );
}
