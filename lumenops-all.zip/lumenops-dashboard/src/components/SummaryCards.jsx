export default function SummaryCards({ summary, incidents }) {
  const completed = incidents.filter((i) => i.status === "Restored").length;
  const openHigh = incidents.filter((i) => i.priority === "High" && i.status !== "Restored").length;
  const needCrew = incidents.filter((i) => i.status === "Pending").length;

  const cards = [
    { label: "Complaints received", value: summary.complaints ?? "-" },
    { label: "Incidents", value: summary.incidents ?? incidents.length },
    { label: "Duplicates merged", value: summary.merged_duplicates ?? "-" },
    { label: "Waiting for a crew", value: needCrew },
    { label: "High priority (open)", value: openHigh, tone: "high" },
    { label: "Completed", value: completed, tone: "ok" },
  ];

  return (
    <section className="cards">
      {cards.map((c) => (
        <div key={c.label} className={"card " + (c.tone || "")}>
          <div className="card-value">{c.value}</div>
          <div className="card-label">{c.label}</div>
        </div>
      ))}
    </section>
  );
}
