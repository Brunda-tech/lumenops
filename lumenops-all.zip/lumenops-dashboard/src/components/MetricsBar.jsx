import { formatDuration } from "../utils.js";

const pct = (v) => (v === null || v === undefined ? "-" : v + "%");

export default function MetricsBar({ metrics }) {
  if (!metrics) return null;
  const cards = [
    {
      label: "Average time to restore",
      value: metrics.avg_restore_minutes === null ? "-" : formatDuration(metrics.avg_restore_minutes),
      note: metrics.restored_complaints ? metrics.restored_complaints + " restored complaints" : "No restored complaints yet",
    },
    {
      label: "Duplicate complaints merged",
      value: pct(metrics.merged_pct),
      note: metrics.ml_available ? "of all complaints" : "ML service not reachable",
    },
    {
      label: "Complaints with a status update",
      value: pct(metrics.updated_pct),
      note: "SMS: " + metrics.sms.sent + " sent, " + metrics.sms.stub + " stub, " + metrics.sms.failed + " failed",
    },
  ];
  return (
    <section className="metrics">
      <h2>Success metrics</h2>
      <div className="mcards">
        {cards.map((c) => (
          <div key={c.label} className="mcard">
            <span>{c.label}</span>
            <b>{c.value}</b>
            <span>{c.note}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
