import { useCallback, useEffect, useState } from "react";
import { fetchAudit } from "../api.js";
import { formatTime } from "../utils.js";

function describe(details) {
  try {
    return Object.entries(JSON.parse(details || "{}")).map(([k, v]) => k + ": " + v).join(", ");
  } catch {
    return "";
  }
}

export default function ActivityPanel({ onAuthError }) {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      setRows((await fetchAudit()).entries);
      setError("");
    } catch (err) {
      if (err.status === 401) onAuthError();
      else setError(err.message);
    }
  }, [onAuthError]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <section className="panel">
      <div className="panel-head">
        <h2>Activity log</h2>
        <button className="refresh" onClick={load}>Refresh</button>
      </div>
      <p className="m">Who did what, newest first. Passwords are never stored here.</p>
      {error && <div className="banner">{error}</div>}
      <table className="tbl">
        <thead><tr><th>Time</th><th>Who</th><th>Action</th><th>Details</th></tr></thead>
        <tbody>
          {(rows || []).map((r) => (
            <tr key={r.id}>
              <td>{formatTime(r.at)}</td>
              <td>{r.actor}{r.role ? " (" + r.role + ")" : ""}</td>
              <td>{r.action.replace(/_/g, " ")}</td>
              <td>{describe(r.details)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
