import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { COLORS, RESTORED_COLOR, escapeHtml, formatDuration } from "../utils.js";

function styleFor(inc, status, selected) {
  const restored = status === "Restored";
  const color = restored ? RESTORED_COLOR : COLORS[inc.priority];
  return {
    color: selected ? "#111827" : color,
    weight: selected ? 4 : 2,
    fillColor: color,
    fillOpacity: restored ? 0.25 : 0.55,
  };
}

function popupHtml(inc, status) {
  const critical = inc.critical_nearby.length
    ? "<br/>Critical: " + inc.critical_nearby.map((s) => escapeHtml(s.name)).join(", ")
    : "";
  return (
    "<strong>" + escapeHtml(inc.id) + " (" + escapeHtml(inc.priority) + ")</strong><br/>" +
    inc.reports + " reports, " + formatDuration(inc.duration_min) + critical +
    "<br/>Status: " + escapeHtml(status)
  );
}

export default function IncidentMap({ incidents, selectedId, onSelect, statuses }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const layerRef = useRef(null);
  const markersRef = useRef({});
  const fittedRef = useRef(false);
  const selectedRef = useRef(selectedId);
  selectedRef.current = selectedId;

  // Create the map once.
  useEffect(() => {
    const map = L.map(containerRef.current).setView([12.9716, 77.5946], 11);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    return () => {
      map.remove();
      mapRef.current = null;
      markersRef.current = {};
      fittedRef.current = false;
    };
  }, []);

  // Redraw circles when incidents or statuses change.
  useEffect(() => {
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!map || !layer) return;
    layer.clearLayers();
    markersRef.current = {};

    incidents.forEach((inc) => {
      const status = statuses[inc.id] || "Pending";
      const marker = L.circleMarker([inc.lat, inc.lng], {
        radius: 10 + Math.sqrt(inc.reports) * 4,
        ...styleFor(inc, status, inc.id === selectedRef.current),
      });
      marker.bindPopup(popupHtml(inc, status));
      marker.on("click", () => onSelect(inc.id));
      marker.addTo(layer);
      markersRef.current[inc.id] = { marker, inc, status };
    });

    if (!fittedRef.current && incidents.length > 0) {
      const bounds = L.latLngBounds(incidents.map((i) => [i.lat, i.lng]));
      map.fitBounds(bounds.pad(0.3), { maxZoom: 14 });
      fittedRef.current = true;
    }
  }, [incidents, statuses, onSelect]);

  // Highlight and zoom to the selected incident.
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    Object.values(markersRef.current).forEach(({ marker, inc, status }) => {
      marker.setStyle(styleFor(inc, status, inc.id === selectedId));
    });
    const entry = selectedId && markersRef.current[selectedId];
    if (entry) {
      map.flyTo(entry.marker.getLatLng(), Math.max(map.getZoom(), 14), { duration: 0.6 });
      entry.marker.openPopup();
    }
  }, [selectedId]);

  return <div ref={containerRef} className="map" />;
}
