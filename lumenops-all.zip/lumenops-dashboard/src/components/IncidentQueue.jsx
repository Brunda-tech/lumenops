import { useState } from "react";
import { STATUS_LABEL, formatDuration, formatTime } from "../utils.js";

const PRIORITIES = ["All", "High", "Medium", "Low"];
const STATUSES = ["All", "Pending", "Crew assigned", "Restored"];

function Breakdown({ b }) {
  return (
    <div>
      <div className="bar">
        <span style={{ width: b.reports + "%" }} className="seg seg-reports" />
        <span style={{ width: b.duration + "%" }} className="seg seg-duration" />
        <span style={{ width: b.critical_load + "%" }} className="seg seg-critical" />
      </div>
      <div className="legend">
        <span><i className="dot seg-reports" /> Reports {b.reports}</span>
        <span><i className="dot seg-duration" /> Duration {b.duration}</span>
        <span><i className="dot seg-critical" /> Critical load {b.critical_load}</span>
      </div>
    </div>
  );
}

export default function IncidentQueue({
  incidents, selectedId, onSelect, role, crews, causes,
  onAssign, onComplete, onReopen, priorityFilter, onPriorityFilter, statusFilter, onStatusFilter,
}) {
  // What the user has typed or picked for each incident (kept when the list refreshes).
  const [drafts, setDrafts] = useState({});
  const draft = (id) => ({ crew: crews[0] || "", cause: causes[0] || "", note: "", ...(drafts[id] || {}) });
  const setDraft = (id, patch) => setDrafts((d) => ({ ...d, [id]: { ...draft(id), ...patch } }));
  const stop = (e) => e.stopPropagation();

  function actions(inc) {
    const d = draft(inc.id);
    if (inc.status === "Pending") {
      if (role !== "admin") return <p className="waiting">Waiting for the admin to assign a crew.</p>;
      return (
        <div className="act" onClick={stop}>
          <select aria-label="Crew" value={d.crew} onChange={(e) => setDraft(inc.id, { crew: e.target.value })}>
            {crews.map((c) => <option key={c}>{c}</option>)}
          </select>
          <button className="action solid" onClick={() => onAssign(inc, d.crew)}>Assign crew</button>
        </div>
      );
    }
    if (inc.status === "Crew assigned") {
      if (role === "supervisor") {
        return (
          <div className="act col" onClick={stop}>
            <div className="m">{inc.crew || "A crew"} is assigned. Check the finished work, then complete it.</div>
            <select aria-label="Cause" value={d.cause} onChange={(e) => setDraft(inc.id, { cause: e.target.value })}>
              {causes.map((c) => <option key={c}>{c}</option>)}
            </select>
            <input aria-label="Note" placeholder="Note (optional)" maxLength={300} value={d.note} onChange={(e) => setDraft(inc.id, { note: e.target.value })} />
            <button className="action solid" onClick={() => onComplete(inc, d.cause, d.note)}>Mark completed</button>
          </div>
        );
      }
      return (
        <div className="act" onClick={stop}>
          <span className="m">{inc.crew || "Crew"} on the way</span>
          <select aria-label="Change crew" value={d.crew} onChange={(e) => setDraft(inc.id, { crew: e.target.value })}>
            {crews.map((c) => <option key={c}>{c}</option>)}
          </select>
          <button className="action" onClick={() => onAssign(inc, d.crew)}>Change crew</button>
        </div>
      );
    }
    return (
      <div className="act" onClick={stop}>
        <span className="m">{inc.cause || "Completed"}{inc.note ? " · " + inc.note : ""}</span>
        <button className="action" onClick={() => onReopen(inc)}>Reopen</button>
      </div>
    );
  }

  return (
    <section className="queue">
      <div className="queue-head">
        <h2>Incidents</h2>
        <div className="filters">
          {PRIORITIES.map((f) => (
            <button key={f} className={"chip " + (priorityFilter === f ? "active" : "")} onClick={() => onPriorityFilter(f)}>{f}</button>
          ))}
        </div>
      </div>
      <div className="filters status-filters">
        {STATUSES.map((f) => (
          <button key={f} className={"chip " + (statusFilter === f ? "active" : "")} onClick={() => onStatusFilter(f)}>
            {f === "All" ? "All statuses" : STATUS_LABEL[f]}
          </button>
        ))}
      </div>

      {incidents.length === 0 && <p className="empty">No incidents in this view.</p>}

      <ul className="list">
        {incidents.map((inc) => {
          const selected = inc.id === selectedId;
          return (
            <li key={inc.id} className={"item " + (selected ? "selected " : "") + (inc.status === "Restored" ? "done" : "")} onClick={() => onSelect(inc.id)}>
              <div className="item-top">
                <span className="rank">#{inc.rank}</span>
                <strong>{inc.id}</strong>
                <span className={"badge " + inc.priority.toLowerCase()}>{inc.priority}</span>
                <span className="score">Score {inc.score}</span>
              </div>
              <div className="meta">
                {inc.reports} {inc.reports === 1 ? "report" : "reports"} &middot; {formatDuration(inc.duration_min)} since first report
              </div>
              {inc.critical_nearby.length > 0 && (
                <div className="critical">Critical load nearby: {inc.critical_nearby.map((s) => s.name).join(", ")}</div>
              )}
              <div className="item-bottom">
                <span className={"status " + inc.status.replace(" ", "-").toLowerCase()}>{STATUS_LABEL[inc.status]}</span>
              </div>
              {actions(inc)}
              {selected && (
                <div className="details">
                  <Breakdown b={inc.breakdown} />
                  <div className="detail-row">First reported: {formatTime(inc.first_reported)}</div>
                  <div className="detail-row">Last reported: {formatTime(inc.last_reported)}</div>
                  <div className="detail-row">
                    Complaints merged: {inc.complaint_ids.length} ({inc.complaint_ids.slice(0, 6).join(", ")}
                    {inc.complaint_ids.length > 6 ? ", ..." : ""})
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}
