// The API is expected on port 4000 of the same machine that served this page.
const BASE = import.meta.env.VITE_API_BASE || `http://${window.location.hostname}:4000`;
export const EVENTS_URL = BASE + "/api/events";

export class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

// The login is kept in sessionStorage: it disappears when the browser tab is closed.
const KEY = "lumenops_staff";
export const session = {
  load() {
    try {
      return JSON.parse(sessionStorage.getItem(KEY) || "null");
    } catch {
      return null;
    }
  },
  save(value) {
    try {
      sessionStorage.setItem(KEY, JSON.stringify(value));
    } catch {
      /* storage not available */
    }
  },
  clear() {
    try {
      sessionStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
  },
};

let token = (session.load() || {}).token || "";
export const setToken = (t) => {
  token = t || "";
};

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(BASE + path, {
      ...options,
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
    });
  } catch {
    throw new ApiError("Cannot reach the server. Is the API running?", 0);
  }
  let body = null;
  try {
    body = await res.json();
  } catch {
    /* no JSON body */
  }
  if (!res.ok) throw new ApiError((body && body.error) || "Something went wrong (HTTP " + res.status + ").", res.status);
  return body;
}

const post = (path, data) => request(path, { method: "POST", body: JSON.stringify(data) });

export const login = (username, password) => post("/api/auth/login", { username, password });
export const fetchIncidents = () => request("/api/incidents");
export const fetchCrews = () => request("/api/crews");
export const fetchApplications = () => request("/api/applications");
export const fetchAudit = () => request("/api/audit");
export const assignCrew = (ids, crew) => post("/api/incidents/assign", { complaint_ids: ids, crew });
export const completeIncident = (ids, cause, note) => post("/api/incidents/complete", { complaint_ids: ids, cause, note });
export const reopenIncident = (ids) => post("/api/incidents/reopen", { complaint_ids: ids });
export const reviewApplication = (ref, decision, note) => post(`/api/applications/${ref}/review`, { decision, note });

// Metrics are optional: a failure just hides the panel (but an expired login still logs the user out).
export async function fetchMetrics() {
  try {
    return await request("/api/metrics");
  } catch (err) {
    if (err.status === 401) throw err;
    return null;
  }
}
