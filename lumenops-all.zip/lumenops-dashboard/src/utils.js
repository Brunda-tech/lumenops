export const COLORS = { High: "#C0392B", Medium: "#D68910", Low: "#2E8B57" };
export const RESTORED_COLOR = "#9CA3AF";

// The API stores "Restored"; the screens call it "Completed".
export const STATUS_LABEL = { Pending: "Needs crew", "Crew assigned": "Crew assigned", Restored: "Completed" };

export function formatDuration(min) {
  if (min < 60) return Math.round(min) + " min";
  return Math.floor(min / 60) + "h " + Math.round(min % 60) + "m";
}

export function formatTime(iso) {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
}

export function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (ch) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]
  ));
}
