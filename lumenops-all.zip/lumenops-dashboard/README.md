# LumenOps Control Room Dashboard (React + Vite)

For BESCOM staff. **Admin** assigns crews, **supervisor** marks the work completed. Everyone signs in first.

## Run
```
# 1. ML service   (lumenops-ml)       pip install -r requirements.txt   then   python app.py      (port 5001)
# 2. Node API     (lumenops-api)      set the passwords, then   npm start                          (port 4000)
# 3. Dashboard    (this folder)       npm install   then   npm run dev                              (port 5173)
```
See the API README for how to set `ADMIN_PASSWORD`, `SUPERVISOR_PASSWORD` and `AUTH_SECRET`. The dashboard needs the API: there is no offline sample mode any more.
To load demo complaints, sign in as admin and run the seed request shown in the API README.

## What each role sees
**Admin**
- Incidents: map and ranked list. Starts on "Needs crew". Pick a crew and press **Assign crew** (or change it later).
- **Connection requests**: approve or reject new connection applications, with a note for the applicant.
- **Activity log**: who did what and when.

**Supervisor**
- Incidents: starts on "Crew assigned". Check the finished work, pick the cause, add a note and press **Mark completed**.
- No admin tabs, no assign button.

**Both**: summary cards, success metrics (time to restore, duplicates merged, complaints updated), filters by priority and status, score breakdown for each incident,
Reopen, live updates (the page refreshes by itself when something changes), sign out.

## Notes
- The sign-in is kept in the browser tab only (sessionStorage). Closing the tab signs you out. If the login expires you are sent back to the sign-in page.
- The screens call the status "Completed". The API stores it as `Restored`.
- Hiding a button is not security: the API checks the role on every request.
- The map needs internet access to load OpenStreetMap tiles. The real Leaflet map was not tested here (no internet in the test environment).
- Change the API address with `VITE_API_BASE` (copy `.env.example` to `.env`).

## Look
The background pictures (pylons, power lines, transformers, a skyline with moving "current") are plain SVG drawn in `src/components/Scene.jsx`, so there are no image files to load.
They and the animations switch off for people whose device asks for reduced motion.

## Files
`src/App.jsx` login gate, tabs, actions. `src/api.js` API calls and login. `src/components/` Login, SummaryCards, MetricsBar, IncidentMap, IncidentQueue, ApplicationsPanel, ActivityPanel.
