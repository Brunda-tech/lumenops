// Builds the incident list: asks the ML service to group + rank complaints, then adds
// crew status and stable incident ids.
import { STATUS_ORDER, allComplaints, criticalSites, formatId, parseId } from "./db.js";
import { analyze } from "./ml.js";

export function minStatus(list) {
  return list.reduce((a, b) => (STATUS_ORDER.indexOf(b) < STATUS_ORDER.indexOf(a) ? b : a));
}

export async function buildIncidents({ db, mlUrl }) {
  const rows = allComplaints(db);
  if (!rows.length) {
    return {
      incidents: [],
      summary: { complaints: 0, incidents: 0, merged_duplicates: 0, high: 0, medium: 0, low: 0, restored: 0 },
    };
  }
  const payload = rows.map((r) => ({ id: formatId(r.id), lat: r.lat, lng: r.lng, timestamp: r.timestamp }));
  const sites = criticalSites(db).map(({ name, type, lat, lng }) => ({ name, type, lat, lng }));
  const result = await analyze(mlUrl, payload, sites, new Date().toISOString());

  const byId = new Map(rows.map((r) => [formatId(r.id), r]));
  const incidents = result.incidents.map((inc) => {
    const status = minStatus(inc.complaint_ids.map((id) => byId.get(id)?.status ?? "Pending"));
    // Stable id: based on the oldest complaint in the incident (ML ids change with ranking).
    const first = Math.min(...inc.complaint_ids.map((id) => parseId(id)));
    const members = inc.complaint_ids.map((id) => byId.get(id)).filter(Boolean);
    const crew = members.find((m) => m.crew)?.crew ?? null;
    const cause = members.find((m) => m.cause)?.cause ?? null;
    const note = members.find((m) => m.resolution_note)?.resolution_note ?? null;
    return { ...inc, ml_rank: inc.rank, id: "INC-" + String(first).padStart(4, "0"), status, crew, cause, note };
  });

  // Open incidents first (by ML rank), restored ones at the bottom.
  incidents.sort((a, b) => (a.status === "Restored") - (b.status === "Restored") || a.ml_rank - b.ml_rank);
  incidents.forEach((inc, i) => {
    inc.rank = i + 1;
  });

  return {
    incidents,
    summary: { ...result.summary, restored: incidents.filter((i) => i.status === "Restored").length },
  };
}
