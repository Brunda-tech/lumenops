# LumenOps API (Node.js)

Stores complaints, asks the ML service to group and rank them, and serves the dashboard and the consumer app.
No `npm install` needed: it uses only Node's built-in modules (HTTP server, SQLite, crypto).

**Needs Node 22.13 or newer** (check with `node -v`). A harmless "SQLite experimental" warning is printed on start.

## Run
Set the staff passwords (at least 8 characters) and a secret, then start. **Pick your own, do not reuse the examples.**

Mac / Linux:
```
ADMIN_PASSWORD='your-admin-password' SUPERVISOR_PASSWORD='your-supervisor-password' AUTH_SECRET='a-long-random-text' npm start
```
Windows PowerShell:
```
$env:ADMIN_PASSWORD="your-admin-password"; $env:SUPERVISOR_PASSWORD="your-supervisor-password"; $env:AUTH_SECRET="a-long-random-text"; npm start
```
- If you do not set a staff password, the API creates a random one the first time and **prints it once** in the console.
- If you do not set `AUTH_SECRET`, a random one is used and everyone has to sign in again after a restart.
- Then load demo complaints (admin only): sign in on the dashboard, or use the API (see below).
- `npm test` runs the self-contained tests (fake ML service, in-memory database).

Other settings (optional): `PORT` (4000), `ML_URL` (http://127.0.0.1:5001), `DB_PATH` (data/lumenops.db), `CREWS` (default "Crew 1,Crew 2,Crew 3,Crew 4"),
`ALLOW_DEMO=false` (switches off the demo seed/reset endpoints), `SANDBOX_BILLS=off` (no sample billing account), `COMPLAINT_RATE_LIMIT` (reports per 10 minutes per connection, default 60).

## Who can do what
| Role | How they get in | What they can do |
|---|---|---|
| Consumer | No login for reporting. For the bill: RR number + last 4 digits of the registered phone | Report an outage, check a complaint's status, view and pay their own sandbox bill, apply for a new connection |
| Admin | Username `admin` + password | See incidents, **assign a crew**, change crew, reopen, review connection requests, critical sites, activity log, demo seed/reset |
| Supervisor | Username `supervisor` + password | See incidents, **mark completed** (only after a crew was assigned, with a cause and note), reopen |

The admin cannot complete work and the supervisor cannot assign crews. That separation is on purpose.

## Workflow rules
1. A consumer reports. Duplicates are merged into one incident (Pending).
2. **Admin** assigns a crew from the list (status "Crew assigned"). Consumers with a phone number get an SMS message.
3. The crew does the work.
4. **Supervisor** marks it completed with a cause (transformer fault, line fault, ...). The API status is `Restored`. Consumers get an SMS message.
5. Anyone on staff can reopen it. A new report in the area also reopens it.
The API refuses to complete an incident that has no crew, to assign a crew to a completed incident, or to use a wrong crew name.

## Endpoints
Staff endpoints need the header `Authorization: Bearer <token>` from `POST /api/auth/login`.

| Endpoint | Who | What it does |
|---|---|---|
| `GET /api/health` | anyone | API status and whether the ML service is up |
| `GET /api/events` | anyone | Live updates (Server-Sent Events). Events carry no personal data |
| `POST /api/auth/login` | anyone | `{username, password}` returns a token (valid 8 hours) |
| `GET /api/auth/me` | any login | Who am I |
| `POST /api/complaints` | anyone | Report an outage: `{lat, lng, type?, phone?, note?}`. Limited per connection |
| `GET /api/complaints/:ref` | anyone with the reference | Status only: no location, note or phone |
| `GET /api/incidents` | staff | Ranked incidents with status, crew, cause, note |
| `POST /api/incidents/assign` | admin | `{complaint_ids, crew}` |
| `POST /api/incidents/complete` | supervisor | `{complaint_ids, cause, note?}` |
| `POST /api/incidents/reopen` | staff | `{complaint_ids}` |
| `GET /api/crews` | staff | Crew names and the list of causes |
| `GET /api/metrics` | staff | Time to restore, duplicates merged, complaints updated, SMS counts |
| `GET/POST /api/critical-sites` | staff / admin | Hospitals, pumping stations, ... used for priority |
| `GET /api/notifications` | staff | SMS messages created (phone numbers masked) |
| `GET /api/audit` | admin | Activity log: who did what, when |
| `POST /api/consumer/login` | anyone | `{rr, last4}` returns a 30 minute token for the bill |
| `GET /api/consumer/bill` | consumer | Own bill and 6 month history |
| `POST /api/consumer/pay` | consumer | `{method}` sandbox payment: **no money moves** |
| `POST /api/applications` | anyone | New connection application. Limited per connection |
| `GET /api/applications/:ref?last4=` | applicant | Status, using the reference and last 4 digits of the phone |
| `GET /api/applications`, `POST /api/applications/:ref/review` | admin | List and approve / reject |
| `POST /api/demo/seed`, `/api/demo/reset` | admin | Load or clear demo complaints (can be switched off) |

Example:
```
curl -X POST localhost:4000/api/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"your-admin-password"}'
curl -X POST localhost:4000/api/demo/seed -H "Authorization: Bearer <token>"
```

## Sandbox bill
The sample account is **RR-DEMO-1042, code 0042**. The usage, amounts and the tariff are made up and are **not BESCOM's real rates**.
Payment records a receipt but moves no money. Real billing would need BESCOM's billing system and a licensed payment gateway.

## Security: what is done
- Passwords are hashed with scrypt. Login tokens are signed (HMAC-SHA256) and expire. A wrong login always gets the same message.
- Failed logins, bill logins and application look-ups are rate limited. Reports and applications are limited per connection.
- Staff actions are written to an activity log with who and when. Passwords and tokens are never logged.
- The public status page returns no location, note or phone. Staff lists mask phone numbers.
- Every staff and consumer endpoint checks the role on the server, not only in the screens.

## Security: what is NOT done (be honest about this)
- **No HTTPS.** Run it only on a trusted network, or put it behind HTTPS before real use. Passwords travel in plain text over http.
- **Only two fixed staff accounts** (admin and supervisor). No separate accounts per person, no password change screen, no token revocation, no two-factor login.
- **CORS allows any website.** Restrict it before real use.
- **The consumer check is weak** (RR number + 4 digits). A real app would use an OTP sent to the phone. Report references are guessable (C0001, C0002), which is why that page shows no personal details.
- Rate limits are kept in memory and reset when the API restarts.

## Real SMS (optional)
By default SMS is a **stub**: messages are saved and printed, nothing is sent (`delivery` = `stub`).
To send real messages, also set `SMS_WEBHOOK_URL` (and `SMS_WEBHOOK_TOKEN`). For every message the API POSTs `{"to": "9876543210", "message": "..."}`
with `Authorization: Bearer <token>` to that URL. `delivery` becomes `sent`, or `failed` if the service answers with an error.
This was tested only against a fake local service. Providers differ (many need a country code like 91, and SMS in India usually needs registered
sender IDs and message templates), so you will probably need a small adapter. SMS is sent for complaints only, not for applications.

## Other limits
- Database is SQLite (not PostgreSQL) and plain Node HTTP (not Express or Socket.IO). Live updates use Server-Sent Events.
- Success metrics are simple counts. The average restore time is per complaint, from the report to "Restored".
- Coordinates are not checked against Bengaluru. Demo data is synthetic.

## Files
`server.js` routes and rules, `auth.js` passwords, tokens and rate limiter, `db.js` SQLite, `incidents.js` merge with ML result,
`bills.js` sandbox billing, `metrics.js`, `notifier.js` SMS, `ml.js` ML client, `seed.js` + `seed/` demo data, `test/api.test.js` tests.
