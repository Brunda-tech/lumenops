// Passwords, signed login tokens and a small rate limiter, using only Node's built-in crypto.
import crypto from "node:crypto";

export function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  return { salt, hash: crypto.scryptSync(password, salt, 64).toString("hex") };
}

export function verifyPassword(password, salt, hash) {
  const got = crypto.scryptSync(password, salt, 64);
  const want = Buffer.from(hash, "hex");
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}

// A token is  base64url(payload) + "." + HMAC-SHA256 signature. It carries { sub, role, exp }.
export function signToken(payload, secret, ttlSeconds) {
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + ttlSeconds })).toString("base64url");
  const sig = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return body + "." + sig;
}

export function verifyToken(token, secret) {
  const [body, sig, extra] = String(token).split(".");
  if (!body || !sig || extra !== undefined) return null;
  const want = crypto.createHmac("sha256", secret).update(body).digest();
  const got = Buffer.from(sig, "base64url");
  if (got.length !== want.length || !crypto.timingSafeEqual(got, want)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    if (typeof payload.exp !== "number" || payload.exp * 1000 < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

// Counts events per key inside a sliding window.
export class RateLimiter {
  constructor(max, windowMs) {
    this.max = max;
    this.windowMs = windowMs;
    this.hits = new Map();
  }
  _recent(key) {
    const cutoff = Date.now() - this.windowMs;
    const list = (this.hits.get(key) || []).filter((t) => t > cutoff);
    if (list.length) this.hits.set(key, list);
    else this.hits.delete(key);
    return list;
  }
  blocked(key) {
    return this._recent(key).length >= this.max;
  }
  hit(key) {
    const list = this._recent(key);
    list.push(Date.now());
    this.hits.set(key, list);
    if (this.hits.size > 5000) for (const k of this.hits.keys()) this._recent(k);
  }
  // Counts the attempt and says whether it is allowed.
  take(key) {
    if (this.blocked(key)) return false;
    this.hit(key);
    return true;
  }
  clear(key) {
    this.hits.delete(key);
  }
}

// Creates the two staff accounts. Passwords come from ADMIN_PASSWORD / SUPERVISOR_PASSWORD.
// If a password is not given and the account does not exist yet, a random one is created and printed once.
export function ensureStaff(db, { adminPassword, supervisorPassword } = {}, log = console.log, store) {
  const wanted = [["admin", adminPassword], ["supervisor", supervisorPassword]];
  for (const [username, password] of wanted) {
    if (password !== undefined && password !== "") {
      if (String(password).length < 8) throw new Error(`${username} password must have at least 8 characters`);
      const { salt, hash } = hashPassword(String(password));
      store.upsertUser(db, username, username, salt, hash);
    } else if (!store.getUser(db, username)) {
      const generated = crypto.randomBytes(9).toString("base64url");
      const { salt, hash } = hashPassword(generated);
      store.upsertUser(db, username, username, salt, hash);
      log(`[auth] Created '${username}' with password: ${generated}   (shown once. Set ${username.toUpperCase()}_PASSWORD to choose your own)`);
    }
  }
}
