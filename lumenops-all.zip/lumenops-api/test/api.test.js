// Self-contained tests: a tiny fake ML service stands in for Flask, SQLite runs in memory.
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { createApp } from "../server.js";
import { insertComplaint, openDb } from "../db.js";

let fakeMl, api, base, mlPort, db, tok;
const servers = [];
const quiet = () => {};
const PASS = { admin: "admin-pass-12", supervisor: "super-pass-12" };

function startFakeMl() {
  return new Promise((resolve) => {
    const s = http.createServer(async (req, res) => {
      if (req.url === "/health") { res.end('{"status":"ok"}'); return; }
      let raw = "";
      for await (const ch of req) raw += ch;
      const { complaints } = JSON.parse(raw);
      const groups = new Map();
      for (const c of complaints) {
        const key = c.lat.toFixed(3) + "," + c.lng.toFixed(3);
        groups.set(key, [...(groups.get(key) || []), c]);
      }
      const incidents = [...groups.values()].map((m, i) => ({
        id: "INC-" + (i + 1), rank: i + 1, lat: m[0].lat, lng: m[0].lng, reports: m.length,
        complaint_ids: m.map((c) => c.id), first_reported: m[0].timestamp, last_reported: m[m.length - 1].timestamp,
        duration_min: 5, critical_nearby: [], score: m.length, priority: "Low",
        breakdown: { reports: 1, duration: 1, critical_load: 0 },
      })).sort((a, b) => b.score - a.score).map((x, i) => ({ ...x, rank: i + 1 }));
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify({ incidents, summary: { complaints: complaints.length, incidents: incidents.length,
        merged_duplicates: complaints.length - incidents.length, high: 0, medium: 0, low: incidents.length } }));
    });
    s.listen(0, () => resolve(s));
  });
}

const post = (path, body, token) =>
  fetch(base + path, { method: "POST", headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) }, body: JSON.stringify(body) });
const get = (path, token) => fetch(base + path, { headers: token ? { Authorization: "Bearer " + token } : {} });
const json = async (r) => r.json();

async function freshApp(mlUrl, opts = {}) {
  db = openDb(":memory:");
  api = createApp({ db, mlUrl, log: quiet, secret: "test-secret", staff: { adminPassword: PASS.admin, supervisorPassword: PASS.supervisor }, ...opts });
  servers.push(api);
  await new Promise((r) => api.listen(0, r));
  base = "http://127.0.0.1:" + api.address().port;
  tok = {};
  for (const role of ["admin", "supervisor"]) {
    const r = await post("/api/auth/login", { username: role, password: PASS[role] });
    if (r.status === 200) tok[role] = (await r.json()).token;
  }
}
const mlOk = () => `http://127.0.0.1:${mlPort}`;

before(async () => { fakeMl = await startFakeMl(); mlPort = fakeMl.address().port; });
after(() => { [fakeMl, ...servers].forEach((s) => { s.closeAllConnections?.(); s.close(); }); });

test("health reports ml up and nothing private", async () => {
  await freshApp(mlOk());
  const r = await json(await get("/api/health"));
  assert.deepEqual(r, { status: "ok", ml: "up" });
});

test("complaint validation and the public status page leaks no location", async () => {
  await freshApp(mlOk());
  assert.equal((await post("/api/complaints", { lat: 200, lng: 77 })).status, 400);
  assert.equal((await post("/api/complaints", { lat: 12.9, lng: "x" })).status, 400);
  assert.equal((await post("/api/complaints", { lat: 12.9, lng: 77.5, type: "bad" })).status, 400);
  assert.equal((await post("/api/complaints", { lat: 12.9, lng: 77.5, phone: "123" })).status, 400);
  assert.equal((await fetch(base + "/api/complaints", { method: "POST", body: "{not json" })).status, 400);
  assert.equal((await post("/api/complaints", [1, 2])).status, 400);
  assert.equal((await get("/api/complaints/C9999")).status, 404);
  assert.equal((await get("/api/nothing")).status, 404);
  await post("/api/complaints", { lat: 12.9, lng: 77.5, phone: "9876543210", note: "private note" });
  const one = await json(await get("/api/complaints/C0001"));
  assert.deepEqual(Object.keys(one).sort(), ["id", "incident", "status", "timestamp"]);
  assert.equal(JSON.stringify(one).includes("private"), false);
});

test("login: right and wrong passwords, tokens, expiry, tampering", async () => {
  await freshApp(mlOk());
  assert.ok(tok.admin && tok.supervisor);
  assert.equal((await post("/api/auth/login", { username: "admin", password: "wrong-password" })).status, 401);
  assert.equal((await post("/api/auth/login", { username: "nobody", password: "whatever-123" })).status, 401);
  assert.equal((await post("/api/auth/login", { username: "admin" })).status, 400);
  const me = await json(await get("/api/auth/me", tok.admin));
  assert.deepEqual(me, { username: "admin", role: "admin" });
  assert.equal((await get("/api/auth/me")).status, 401);
  assert.equal((await get("/api/auth/me", tok.admin + "x")).status, 401);
  const [body, sig] = tok.admin.split(".");
  const forged = Buffer.from(JSON.stringify({ sub: "admin", role: "admin", exp: 9999999999 })).toString("base64url");
  assert.equal((await get("/api/auth/me", forged + "." + sig)).status, 401);
  assert.equal((await get("/api/auth/me", body + ".")).status, 401);

  await freshApp(mlOk(), { staffTtl: -10 });                       // tokens that are already expired
  const r = await post("/api/auth/login", { username: "admin", password: PASS.admin });
  assert.equal((await get("/api/auth/me", (await r.json()).token)).status, 401);
});

test("login is rate limited after repeated failures", async () => {
  await freshApp(mlOk(), { limits: { loginMax: 3 } });
  for (let i = 0; i < 3; i++) assert.equal((await post("/api/auth/login", { username: "admin", password: "bad-password-" + i })).status, 401);
  assert.equal((await post("/api/auth/login", { username: "admin", password: PASS.admin })).status, 429);   // even the right one
  assert.equal((await post("/api/auth/login", { username: "supervisor", password: PASS.supervisor })).status, 200);   // other account unaffected
});

test("staff accounts: generated password when none is given, short passwords refused", async () => {
  const lines = [];
  const d = openDb(":memory:");
  const app = createApp({ db: d, mlUrl: mlOk(), log: (l) => lines.push(l), secret: "s", staff: {} });
  servers.push(app);
  assert.equal(lines.filter((l) => l.includes("Created")).length, 2);
  assert.throws(() => createApp({ db: openDb(":memory:"), mlUrl: mlOk(), log: quiet, staff: { adminPassword: "short" } }), /at least 8/);
});

test("who may do what", async () => {
  await freshApp(mlOk());
  for (const path of ["/api/incidents", "/api/metrics", "/api/critical-sites", "/api/notifications", "/api/crews", "/api/audit", "/api/applications"]) {
    assert.equal((await get(path)).status, 401, path + " without login");
  }
  assert.equal((await get("/api/audit", tok.supervisor)).status, 403);
  assert.equal((await get("/api/applications", tok.supervisor)).status, 403);
  assert.equal((await post("/api/critical-sites", { name: "x", lat: 1, lng: 1 }, tok.supervisor)).status, 403);
  assert.equal((await post("/api/demo/seed", {}, tok.supervisor)).status, 403);
  assert.equal((await post("/api/demo/seed", {})).status, 401);
  assert.equal((await get("/api/incidents", tok.supervisor)).status, 200);
  assert.equal((await get("/api/incidents", tok.admin)).status, 200);
});

test("crew workflow: admin assigns, supervisor completes, rules are enforced", async () => {
  await freshApp(mlOk());
  await post("/api/complaints", { lat: 12.9251, lng: 77.5831, phone: "9876543210" });
  await post("/api/complaints", { lat: 12.9252, lng: 77.5832 });
  await post("/api/complaints", { lat: 13.05, lng: 77.6 });
  let inc = (await json(await get("/api/incidents", tok.admin))).incidents;
  assert.equal(inc.length, 2);
  assert.equal(inc[0].id, "INC-0001");
  assert.equal(inc[0].status, "Pending");
  const ids = inc[0].complaint_ids;

  assert.equal((await post("/api/incidents/complete", { complaint_ids: ids, cause: "Line fault" }, tok.supervisor)).status, 409);   // no crew yet
  assert.equal((await post("/api/incidents/assign", { complaint_ids: ids, crew: "Crew 2" }, tok.supervisor)).status, 403);
  assert.equal((await post("/api/incidents/assign", { complaint_ids: ids, crew: "Crew 99" }, tok.admin)).status, 400);
  assert.equal((await post("/api/incidents/assign", { complaint_ids: ["C0777"], crew: "Crew 2" }, tok.admin)).status, 404);
  assert.equal((await post("/api/incidents/assign", { complaint_ids: [], crew: "Crew 2" }, tok.admin)).status, 400);

  const a = await json(await post("/api/incidents/assign", { complaint_ids: ids, crew: "Crew 2" }, tok.admin));
  assert.deepEqual(a, { updated: 2, notified: 1 });                         // only C0001 has a phone
  inc = (await json(await get("/api/incidents", tok.admin))).incidents;
  assert.equal(inc[0].status, "Crew assigned");
  assert.equal(inc[0].crew, "Crew 2");
  assert.equal((await post("/api/incidents/assign", { complaint_ids: ids, crew: "Crew 3" }, tok.admin)).status, 200);   // crew can be changed
  assert.equal((await json(await get("/api/incidents", tok.admin))).incidents[0].crew, "Crew 3");

  // a new report joining the incident inherits the crew
  const c = await json(await post("/api/complaints", { lat: 12.9251, lng: 77.5831 }));
  assert.equal(c.status, "Crew assigned");

  assert.equal((await post("/api/incidents/complete", { complaint_ids: ids, cause: "Line fault" }, tok.admin)).status, 403);   // admin cannot complete
  assert.equal((await post("/api/incidents/complete", { complaint_ids: ids, cause: "Nonsense" }, tok.supervisor)).status, 400);
  const all = [...ids, "C0004"];
  const done = await json(await post("/api/incidents/complete", { complaint_ids: all, cause: "Transformer fault", note: "Replaced fuse" }, tok.supervisor));
  assert.equal(done.updated, 3);
  inc = (await json(await get("/api/incidents", tok.admin))).incidents;
  const closed = inc.find((i) => i.id === "INC-0001");
  assert.equal(closed.status, "Restored");
  assert.equal(closed.cause, "Transformer fault");
  assert.equal(closed.note, "Replaced fuse");
  assert.equal(inc.at(-1).id, "INC-0001");                                    // completed ones go last
  assert.equal((await post("/api/incidents/complete", { complaint_ids: all, cause: "Line fault" }, tok.supervisor)).status, 409);
  assert.equal((await post("/api/incidents/assign", { complaint_ids: all, crew: "Crew 1" }, tok.admin)).status, 409);

  // consumer status page follows, then reopening
  assert.equal((await json(await get("/api/complaints/C0001"))).status, "Restored");
  await post("/api/incidents/reopen", { complaint_ids: all }, tok.supervisor);
  const re = (await json(await get("/api/incidents", tok.admin))).incidents.find((i) => i.id === "INC-0001");
  assert.equal(re.status, "Pending");
  assert.equal(re.crew, null);

  const notes = (await json(await get("/api/notifications", tok.admin))).notifications;
  assert.ok(notes.length >= 2);
  assert.match(notes[0].phone, /^\*{6}\d{4}$/);
});

test("activity log records who did what", async () => {
  await freshApp(mlOk());
  await post("/api/complaints", { lat: 12.9, lng: 77.5 });
  await post("/api/incidents/assign", { complaint_ids: ["C0001"], crew: "Crew 1" }, tok.admin);
  await post("/api/incidents/complete", { complaint_ids: ["C0001"], cause: "Other" }, tok.supervisor);
  await post("/api/auth/login", { username: "admin", password: "bad-password" });
  const e = (await json(await get("/api/audit", tok.admin))).entries;
  const has = (action, actor) => e.some((x) => x.action === action && x.actor === actor);
  assert.ok(has("login", "admin") && has("login", "supervisor"));
  assert.ok(has("assign_crew", "admin"));
  assert.ok(has("complete", "supervisor"));
  assert.ok(has("login_failed", "admin"));
  assert.equal(JSON.stringify(e).includes(PASS.admin), false);               // never logs passwords
});

test("success metrics", async () => {
  await freshApp(mlOk());
  assert.equal((await json(await get("/api/metrics", tok.admin))).avg_restore_minutes, null);
  insertComplaint(db, { lat: 12.9, lng: 77.5, timestamp: new Date(Date.now() - 3600e3).toISOString() });
  await post("/api/complaints", { lat: 12.9, lng: 77.5 });
  await post("/api/complaints", { lat: 13.1, lng: 77.7 });
  await post("/api/incidents/assign", { complaint_ids: ["C0001"], crew: "Crew 1" }, tok.admin);
  await post("/api/incidents/complete", { complaint_ids: ["C0001"], cause: "Line fault" }, tok.supervisor);
  const m = await json(await get("/api/metrics", tok.supervisor));
  assert.equal(m.complaints, 3);
  assert.equal(m.restored_complaints, 1);
  assert.ok(m.avg_restore_minutes >= 59.9 && m.avg_restore_minutes <= 61, String(m.avg_restore_minutes));
  assert.equal(m.updated_pct, 33.3);
  assert.equal(m.incidents, 2);
  assert.equal(m.merged_pct, 33.3);
  await post("/api/incidents/reopen", { complaint_ids: ["C0001"] }, tok.admin);
  assert.equal((await json(await get("/api/metrics", tok.admin))).avg_restore_minutes, null);
});

test("metrics and incidents when the ML service is down", async () => {
  await freshApp("http://127.0.0.1:1");
  assert.equal((await json(await get("/api/health"))).ml, "down");
  const r = await post("/api/complaints", { lat: 12.9, lng: 77.5 });
  assert.equal(r.status, 201);
  const j = await json(r);
  assert.equal(j.ml_available, false);
  assert.equal(j.incident, null);
  assert.equal((await get("/api/incidents", tok.admin)).status, 503);
  const m = await json(await get("/api/metrics", tok.admin));
  assert.equal(m.ml_available, false);
  assert.equal(m.complaints, 1);
  assert.equal((await json(await get("/api/complaints/C0001"))).status, "Pending");
});

test("critical sites, demo seed and reset (admin only), CORS", async () => {
  await freshApp(mlOk());
  assert.equal((await post("/api/critical-sites", { name: "Test Hospital", type: "hospital", lat: 12.9, lng: 77.6 }, tok.admin)).status, 201);
  assert.equal((await post("/api/critical-sites", { lat: 12.9, lng: 77.6 }, tok.admin)).status, 400);
  assert.equal((await json(await get("/api/critical-sites", tok.supervisor))).sites.length, 1);
  assert.equal((await json(await post("/api/demo/seed", {}, tok.admin))).complaints, 58);
  assert.equal((await json(await get("/api/incidents", tok.admin))).summary.complaints, 58);
  await post("/api/demo/reset", {}, tok.admin);
  assert.equal((await json(await get("/api/incidents", tok.admin))).incidents.length, 0);
  const pre = await fetch(base + "/api/incidents", { method: "OPTIONS" });
  assert.equal(pre.status, 204);
  assert.match(pre.headers.get("access-control-allow-headers"), /Authorization/);
  await freshApp(mlOk(), { allowDemo: false });
  assert.equal((await post("/api/demo/seed", {}, tok.admin)).status, 404);
});

test("complaints are rate limited per connection", async () => {
  await freshApp(mlOk(), { limits: { complaintMax: 3 } });
  for (let i = 0; i < 3; i++) assert.equal((await post("/api/complaints", { lat: 12.9, lng: 77.5 })).status, 201);
  assert.equal((await post("/api/complaints", { lat: 12.9, lng: 77.5 })).status, 429);
});

test("sandbox bill: login by RR number and phone digits, view, pay once", async () => {
  await freshApp(mlOk());
  assert.equal((await post("/api/consumer/login", { rr: "RR-DEMO-1042", last4: "9999" })).status, 401);
  assert.equal((await post("/api/consumer/login", { rr: "RR-NOPE", last4: "0042" })).status, 401);
  assert.equal((await post("/api/consumer/login", { rr: "RR-DEMO-1042", last4: "12" })).status, 400);
  const login = await json(await post("/api/consumer/login", { rr: "rr-demo-1042", last4: "0042" }));
  const t = login.token;
  assert.equal(login.rr, "RR-DEMO-1042");
  assert.equal((await get("/api/consumer/bill")).status, 401);
  assert.equal((await get("/api/consumer/bill", tok.admin)).status, 403);        // staff token is not a consumer token
  assert.equal((await get("/api/incidents", t)).status, 403);                    // consumer token cannot open the control room
  const b = await json(await get("/api/consumer/bill", t));
  assert.equal(b.sandbox, true);
  assert.equal(b.bills.length, 6);
  assert.equal(b.bills[0].status, "Unpaid");                                     // newest month first
  assert.ok(b.bills.slice(1).every((x) => x.status === "Paid"));
  assert.equal(b.bills[0].units, 127);
  assert.equal(b.bills[0].amount, 724);                                         // 60 + 200 + 275 + 27 x 7 (sample tariff)
  assert.equal(JSON.stringify(b).includes("91000000"), false);                   // phone not exposed

  assert.equal((await post("/api/consumer/pay", { method: "Bitcoin" }, t)).status, 400);
  const paid = await json(await post("/api/consumer/pay", { method: "UPI" }, t));
  assert.match(paid.receipt, /^PAY-\d{6}$/);
  assert.equal(paid.sandbox, true);
  assert.equal((await post("/api/consumer/pay", { method: "UPI" }, t)).status, 404);          // nothing left to pay
  assert.equal((await post("/api/consumer/pay", { method: "UPI", bill_id: b.bills[0].id }, t)).status, 409);
  assert.equal((await json(await get("/api/consumer/bill", t))).bills[0].status, "Paid");
});

test("bill login is rate limited", async () => {
  await freshApp(mlOk(), { limits: { loginMax: 3 } });
  for (let i = 0; i < 3; i++) assert.equal((await post("/api/consumer/login", { rr: "RR-DEMO-1042", last4: "000" + i })).status, 401);
  assert.equal((await post("/api/consumer/login", { rr: "RR-DEMO-1042", last4: "0042" })).status, 429);
});

test("new connection applications", { timeout: 15000 }, async () => {
  await freshApp(mlOk(), { limits: { applicationMax: 8, loginMax: 3 } });
  const ok = { name: "Test Person", address: "1 Test Road", type: "Domestic", load_kw: 3, phone: "9876543210" };
  assert.equal((await post("/api/applications", { ...ok, name: "" })).status, 400);
  assert.equal((await post("/api/applications", { ...ok, load_kw: 0 })).status, 400);
  assert.equal((await post("/api/applications", { ...ok, type: "Industrial" })).status, 400);
  assert.equal((await post("/api/applications", { ...ok, phone: "12" })).status, 400);
  const created = await post("/api/applications", ok);
  assert.equal(created.status, 201);
  const { ref } = await created.json();
  assert.equal(ref, "APP-0001");

  const st = await json(await get(`/api/applications/${ref}?last4=3210`));
  assert.equal(st.status, "Submitted");
  assert.equal(st.name, undefined);                                              // no personal details back
  assert.equal((await get(`/api/applications/${ref}?last4=0000`)).status, 404);

  const list = (await json(await get("/api/applications", tok.admin))).applications;
  assert.equal(list.length, 1);
  assert.equal(list[0].phone, "******3210");
  assert.equal((await post(`/api/applications/${ref}/review`, { decision: "Approved" }, tok.supervisor)).status, 403);
  assert.equal((await post(`/api/applications/${ref}/review`, { decision: "Maybe" }, tok.admin)).status, 400);
  assert.equal((await post("/api/applications/APP-0099/review", { decision: "Approved" }, tok.admin)).status, 404);
  assert.equal((await post(`/api/applications/${ref}/review`, { decision: "Approved", note: "Visit scheduled" }, tok.admin)).status, 200);
  assert.equal((await post(`/api/applications/${ref}/review`, { decision: "Rejected" }, tok.admin)).status, 409);
  const after = await json(await get(`/api/applications/${ref}?last4=3210`));
  assert.equal(after.status, "Approved");
  assert.equal(after.review_note, "Visit scheduled");

  // 5 attempts so far (4 invalid + 1 valid). Every attempt counts, so the 9th is refused.
  for (let i = 0; i < 3; i++) assert.equal((await post("/api/applications", ok)).status, 201);
  assert.equal((await post("/api/applications", ok)).status, 429);
  for (let i = 0; i < 3; i++) await get(`/api/applications/${ref}?last4=111${i}`);
  assert.equal((await get(`/api/applications/${ref}?last4=3210`)).status, 429);  // guessing is blocked
});

test("server-sent events tell clients when something changes", { timeout: 15000 }, async () => {
  await freshApp(mlOk());
  const res = await get("/api/events");
  assert.equal(res.headers.get("content-type"), "text/event-stream");
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "";
  const readUntil = async (needle) => {
    while (!buf.includes(needle)) {
      const { value, done } = await reader.read();
      if (done) return false;
      buf += dec.decode(value);
    }
    return true;
  };
  assert.ok(await readUntil("event: hello"));
  await post("/api/complaints", { lat: 12.9, lng: 77.5 });
  assert.ok(await readUntil('"reason":"new-complaint"'));
  await post("/api/incidents/assign", { complaint_ids: ["C0001"], crew: "Crew 1" }, tok.admin);
  assert.ok(await readUntil('"reason":"status"'));
  await post("/api/demo/reset", {}, tok.admin);
  assert.ok(await readUntil('"reason":"reset"'));
  assert.equal(buf.includes("9876"), false);
  await reader.cancel();
});

test("SMS: stub by default, webhook when configured, failure recorded", { timeout: 20000 }, async () => {
  const received = [];
  let respondWith = 200;
  const hook = http.createServer(async (req, res) => {
    let raw = "";
    for await (const ch of req) raw += ch;
    received.push({ auth: req.headers.authorization, body: JSON.parse(raw) });
    res.statusCode = respondWith;
    res.end("{}");
  });
  await new Promise((r) => hook.listen(0, r));
  const hookUrl = `http://127.0.0.1:${hook.address().port}/sms`;
  const waitFor = async (fn) => {
    for (let i = 0; i < 40; i++) { const v = await fn(); if (v) return v; await new Promise((r) => setTimeout(r, 50)); }
    throw new Error("timed out");
  };
  const notes = async () => (await json(await get("/api/notifications", tok.admin))).notifications;
  try {
    await freshApp(mlOk());
    await post("/api/complaints", { lat: 12.9, lng: 77.5, phone: "9876543210" });
    delete process.env.SMS_WEBHOOK_URL;
    await post("/api/incidents/assign", { complaint_ids: ["C0001"], crew: "Crew 1" }, tok.admin);
    await waitFor(async () => (await notes()).find((n) => n.delivery === "stub"));
    assert.equal(received.length, 0);

    process.env.SMS_WEBHOOK_URL = hookUrl;
    process.env.SMS_WEBHOOK_TOKEN = "secret-token";
    await post("/api/incidents/complete", { complaint_ids: ["C0001"], cause: "Line fault" }, tok.supervisor);
    await waitFor(async () => (await notes()).find((n) => n.delivery === "sent"));
    assert.equal(received.length, 1);
    assert.equal(received[0].auth, "Bearer secret-token");
    assert.equal(received[0].body.to, "9876543210");
    assert.match(received[0].body.message, /restored/);

    respondWith = 500;
    await post("/api/incidents/reopen", { complaint_ids: ["C0001"] }, tok.admin);
    await post("/api/incidents/assign", { complaint_ids: ["C0001"], crew: "Crew 2" }, tok.admin);
    await waitFor(async () => (await notes()).find((n) => n.delivery === "failed"));
  } finally {
    delete process.env.SMS_WEBHOOK_URL;
    delete process.env.SMS_WEBHOOK_TOKEN;
    hook.closeAllConnections?.();
    hook.close();
  }
});
