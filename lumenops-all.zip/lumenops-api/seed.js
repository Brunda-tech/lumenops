// Demo data: synthetic complaints (same as the ML project). Timestamps are shifted so the newest
// complaint is about 2 minutes old, which makes the demo look live.
import fs from "node:fs";
import { insertMany, resetAll } from "./db.js";

const read = (name) => JSON.parse(fs.readFileSync(new URL("./seed/" + name, import.meta.url), "utf8"));

export function seedDemo(db) {
  const complaints = read("sample_complaints.json");
  const sites = read("critical_sites.json");
  const latest = Math.max(...complaints.map((c) => Date.parse(c.timestamp)));
  const shift = Date.now() - 2 * 60 * 1000 - latest;

  resetAll(db);
  insertMany(
    db,
    complaints.map((c, i) => ({
      lat: c.lat,
      lng: c.lng,
      type: "no_power",
      // obviously fake numbers on every 10th complaint so the SMS stub has something to show
      phone: i % 10 === 0 ? "91000000" + String(i).padStart(4, "0") : null,
      note: null,
      timestamp: new Date(Date.parse(c.timestamp) + shift).toISOString(),
      status: "Pending",
    })),
    sites
  );
  return { complaints: complaints.length, critical_sites: sites.length };
}
