// Success metrics from slide 8: time to restore, share of duplicates merged, complaints that got an update.
import { allComplaints, deliveryCounts } from "./db.js";
import { buildIncidents } from "./incidents.js";
import { MlError } from "./ml.js";

const round1 = (x) => Math.round(x * 10) / 10;

export async function computeMetrics(ctx) {
  const rows = allComplaints(ctx.db);
  const total = rows.length;

  const minutes = rows
    .filter((r) => r.status === "Restored" && r.restored_at)
    .map((r) => (Date.parse(r.restored_at) - Date.parse(r.timestamp)) / 60000)
    .filter((m) => m >= 0);
  const updated = rows.filter((r) => r.status !== "Pending").length;

  const out = {
    complaints: total,
    avg_restore_minutes: minutes.length ? round1(minutes.reduce((a, b) => a + b, 0) / minutes.length) : null,
    restored_complaints: minutes.length,
    updated_complaints: updated,
    updated_pct: total ? round1((100 * updated) / total) : null,
    incidents: null,
    open_incidents: null,
    restored_incidents: null,
    merged_pct: null,
    ml_available: true,
    sms: deliveryCounts(ctx.db),
    definitions: {
      avg_restore_minutes: "Average minutes from the report to 'Restored', over restored complaints",
      merged_pct: "Share of complaints that did not become a separate incident (merged as duplicates)",
      updated_pct: "Share of complaints whose status moved past 'Pending' (crew assigned or restored)",
    },
  };

  try {
    const { incidents } = await buildIncidents(ctx);
    out.incidents = incidents.length;
    out.restored_incidents = incidents.filter((i) => i.status === "Restored").length;
    out.open_incidents = incidents.length - out.restored_incidents;
    out.merged_pct = total ? round1((100 * (total - incidents.length)) / total) : null;
  } catch (err) {
    if (!(err instanceof MlError)) throw err;
    out.ml_available = false;
  }
  return out;
}
