// LumenOps API (Node, no dependencies). Run: node server.js
import http from "node:http";
import crypto from "node:crypto";
import { pathToFileURL } from "node:url";
import * as D from "./db.js";
import { RateLimiter, ensureStaff, hashPassword, signToken, verifyPassword, verifyToken } from "./auth.js";
import { seedSampleBilling } from "./bills.js";
import { buildIncidents, minStatus } from "./incidents.js";
import { computeMetrics } from "./metrics.js";
import { MlError, mlHealth } from "./ml.js";
import { maskPhone, notifyStatusChange } from "./notifier.js";
import { seedDemo } from "./seed.js";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const COMPLAINT_TYPES = ["no_power", "partial", "low_voltage"];
const CAUSES = ["Transformer fault", "Line fault", "Fuse or low-voltage fault", "Planned work", "Other"];
const PAY_METHODS = ["UPI", "Card", "Net banking"];
const STAFF = ["admin", "supervisor"];
const DUMMY = hashPassword("not-a-real-password"); // used so unknown usernames take as long as real ones

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function send(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Content-Length": Buffer.byteLength(data),
    "X-Content-Type-Options": "nosniff",
    "Cache-Control": "no-store",
    ...CORS,
  });
  res.end(data);
}

async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 100_000) throw new HttpError(413, "Request body too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  let body;
  try {
    body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new HttpError(400, "Body must be valid JSON");
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) throw new HttpError(400, "Body must be a JSON object");
  return body;
}

const isNum = (v) => typeof v === "number" && Number.isFinite(v);
const ipOf = (req) => req.socket.remoteAddress || "unknown";
const digitsOnly = (v) => String(v).replace(/[\s+-]/g, "");

function validateLocation(body) {
  if (!isNum(body.lat) || body.lat < -90 || body.lat > 90) throw new HttpError(400, "lat must be a number between -90 and 90");
  if (!isNum(body.lng) || body.lng < -180 || body.lng > 180) throw new HttpError(400, "lng must be a number between -180 and 180");
}

function validatePhone(value, required) {
  if (value === undefined || value === null || value === "") {
    if (required) throw new HttpError(400, "phone is required");
    return null;
  }
  const digits = digitsOnly(value);
  if (!/^\d{10,13}$/.test(digits)) throw new HttpError(400, "phone must have 10 to 13 digits");
  return digits;
}

function validateComplaint(body) {
  validateLocation(body);
  const type = body.type ?? "no_power";
  if (!COMPLAINT_TYPES.includes(type)) throw new HttpError(400, "type must be one of: " + COMPLAINT_TYPES.join(", "));
  const phone = validatePhone(body.phone, false);
  let note = null;
  if (body.note !== undefined && body.note !== null && body.note !== "") {
    if (typeof body.note !== "string" || body.note.length > 300) throw new HttpError(400, "note must be text up to 300 characters");
    note = body.note.trim();
  }
  return { lat: body.lat, lng: body.lng, type, phone, note };
}

function text(value, field, max) {
  if (typeof value !== "string" || !value.trim() || value.trim().length > max) throw new HttpError(400, `${field} is required (max ${max} characters)`);
  return value.trim();
}

export function createApp({
  db,
  mlUrl = process.env.ML_URL || "http://127.0.0.1:5001",
  log = console.log,
  secret = process.env.AUTH_SECRET || crypto.randomBytes(32).toString("hex"),
  staff = { adminPassword: process.env.ADMIN_PASSWORD, supervisorPassword: process.env.SUPERVISOR_PASSWORD },
  crews = (process.env.CREWS || "Crew 1,Crew 2,Crew 3,Crew 4").split(",").map((s) => s.trim()).filter(Boolean),
  staffTtl = 8 * 3600,
  consumerTtl = 30 * 60,
  allowDemo = process.env.ALLOW_DEMO !== "false",
  sandboxBills = process.env.SANDBOX_BILLS !== "off",
  limits = {},
}) {
  const ctx = { db, mlUrl };
  const L = {
    loginMax: 5, loginWindowMs: 10 * 60_000,
    complaintMax: Number(process.env.COMPLAINT_RATE_LIMIT) || 60, complaintWindowMs: 10 * 60_000,
    applicationMax: 10, applicationWindowMs: 60 * 60_000,
    ...limits,
  };
  const loginLimiter = new RateLimiter(L.loginMax, L.loginWindowMs); // failed staff / consumer logins
  const lookupLimiter = new RateLimiter(L.loginMax, L.loginWindowMs); // failed application lookups
  const complaintLimiter = new RateLimiter(L.complaintMax, L.complaintWindowMs);
  const applicationLimiter = new RateLimiter(L.applicationMax, L.applicationWindowMs);

  ensureStaff(db, staff, log, D);
  if (sandboxBills) seedSampleBilling(db);

  // Live updates (Server-Sent Events). The events contain no personal data.
  const clients = new Set();
  const broadcast = (type, data = {}) => {
    const msg = `event: ${type}\ndata: ${JSON.stringify({ ...data, at: new Date().toISOString() })}\n\n`;
    for (const res of clients) res.write(msg);
  };
  const heartbeat = setInterval(() => {
    for (const res of clients) res.write(": ping\n\n");
  }, 25000);
  heartbeat.unref();

  const need = (req, ...roles) => {
    if (!req.user) throw new HttpError(401, "Please log in");
    if (roles.length && !roles.includes(req.user.role)) throw new HttpError(403, "You do not have permission for this action");
  };
  const audit = (req, action, details = {}) =>
    D.addAudit(db, req.user ? req.user.sub : "public", req.user ? req.user.role : null, action, JSON.stringify(details));

  function loadRows(ids) {
    if (!Array.isArray(ids) || ids.length === 0 || ids.length > 5000) throw new HttpError(400, "complaint_ids must be a non-empty list");
    const nums = [...new Set(ids.map(D.parseId))];
    if (nums.some((n) => n === null)) throw new HttpError(400, "complaint_ids contains an invalid id");
    const rows = nums.map((n) => D.getComplaint(db, n));
    if (rows.some((r) => !r)) throw new HttpError(404, "complaint_ids contains an unknown id");
    return rows;
  }

  const routes = [
    ["GET", /^\/$/, async () => ({ name: "LumenOps API", docs: "See README.md" })],

    ["GET", /^\/api\/health$/, async () => ({ status: "ok", ml: (await mlHealth(mlUrl)) ? "up" : "down" })],

    // ---------- login ----------
    ["POST", /^\/api\/auth\/login$/, async (req) => {
      const { username, password } = await readJson(req);
      if (typeof username !== "string" || typeof password !== "string" || !username || username.length > 40 || password.length > 200) {
        throw new HttpError(400, "username and password are required");
      }
      const name = username.trim().toLowerCase();
      const key = ipOf(req) + "|" + name;
      if (loginLimiter.blocked(key)) throw new HttpError(429, "Too many failed attempts. Try again in a few minutes.");
      const user = D.getUser(db, name);
      const ok = user ? verifyPassword(password, user.salt, user.hash) : (verifyPassword(password, DUMMY.salt, DUMMY.hash), false);
      if (!ok) {
        loginLimiter.hit(key);
        D.addAudit(db, name.slice(0, 40), null, "login_failed", "");
        throw new HttpError(401, "Wrong username or password");
      }
      loginLimiter.clear(key);
      D.addAudit(db, user.username, user.role, "login", "");
      return { token: signToken({ sub: user.username, role: user.role }, secret, staffTtl), username: user.username, role: user.role, expires_in: staffTtl };
    }],

    ["GET", /^\/api\/auth\/me$/, async (req) => {
      need(req, ...STAFF, "consumer");
      return { username: req.user.sub, role: req.user.role };
    }],

    ["GET", /^\/api\/crews$/, async (req) => { need(req, ...STAFF); return { crews, causes: CAUSES }; }],

    // ---------- complaints (public: consumers do not log in) ----------
    ["POST", /^\/api\/complaints$/, async (req) => {
      if (!complaintLimiter.take(ipOf(req))) throw new HttpError(429, "Too many reports from this connection. Please wait a few minutes.");
      const c = validateComplaint(await readJson(req));
      const id = D.insertComplaint(db, { ...c, timestamp: new Date().toISOString(), status: "Pending" });
      const ref = D.formatId(id);
      let incident = null;
      let mlAvailable = true;
      try {
        const { incidents } = await buildIncidents(ctx);
        let inc = incidents.find((i) => i.complaint_ids.includes(ref));
        if (inc) {
          // A report that joins an incident whose crew is already assigned starts as "Crew assigned".
          const others = inc.complaint_ids.filter((x) => x !== ref).map((x) => D.getComplaint(db, D.parseId(x)));
          if (others.length && minStatus(others.map((o) => o.status)) === "Crew assigned") {
            D.assignCrew(db, [id], others.find((o) => o.crew)?.crew ?? null, "system");
            inc = { ...inc, status: "Crew assigned" };
          }
          incident = { id: inc.id, reports: inc.reports, priority: inc.priority, status: inc.status };
        }
      } catch (err) {
        if (!(err instanceof MlError)) throw err;
        mlAvailable = false;
      }
      broadcast("incidents-changed", { reason: "new-complaint" });
      const row = D.getComplaint(db, id);
      return { status: 201, body: { id: ref, timestamp: row.timestamp, status: row.status, incident, ml_available: mlAvailable } };
    }],

    // Public status page. It returns no location, note or phone number.
    ["GET", /^\/api\/complaints\/([^/]+)$/, async (req, m) => {
      const n = D.parseId(decodeURIComponent(m[1]));
      const row = n === null ? null : D.getComplaint(db, n);
      if (!row) throw new HttpError(404, "Complaint not found");
      const ref = D.formatId(row.id);
      let incident = null;
      try {
        const { incidents } = await buildIncidents(ctx);
        const inc = incidents.find((i) => i.complaint_ids.includes(ref));
        if (inc) incident = { reports: inc.reports, status: inc.status };
      } catch (err) {
        if (!(err instanceof MlError)) throw err;
      }
      return { id: ref, timestamp: row.timestamp, status: incident ? incident.status : row.status, incident };
    }],

    // ---------- control room (staff only) ----------
    ["GET", /^\/api\/incidents$/, async (req) => {
      need(req, ...STAFF);
      try {
        return await buildIncidents(ctx);
      } catch (err) {
        if (err instanceof MlError) {
          return { status: 503, body: { error: "ML service unavailable. Start it with: python app.py (in lumenops-ml).", detail: err.message } };
        }
        throw err;
      }
    }],

    // Admin assigns a crew.
    ["POST", /^\/api\/incidents\/assign$/, async (req) => {
      need(req, "admin");
      const body = await readJson(req);
      const crew = typeof body.crew === "string" ? body.crew.trim() : "";
      if (!crews.includes(crew)) throw new HttpError(400, "crew must be one of: " + crews.join(", "));
      const rows = loadRows(body.complaint_ids);
      if (rows.some((r) => r.status === "Restored")) throw new HttpError(409, "This incident is already completed. Reopen it first.");
      const newlyAssigned = rows.filter((r) => r.status !== "Crew assigned");
      D.assignCrew(db, rows.map((r) => r.id), crew, req.user.sub);
      let notified = 0;
      for (const r of newlyAssigned) if (notifyStatusChange(db, r, "Crew assigned", log)) notified++;
      audit(req, "assign_crew", { complaints: rows.length, crew });
      broadcast("incidents-changed", { reason: "status" });
      return { updated: rows.length, notified };
    }],

    // Supervisor marks the work completed (only after a crew was assigned).
    ["POST", /^\/api\/incidents\/complete$/, async (req) => {
      need(req, "supervisor");
      const body = await readJson(req);
      if (!CAUSES.includes(body.cause)) throw new HttpError(400, "cause must be one of: " + CAUSES.join(", "));
      let note = null;
      if (body.note !== undefined && body.note !== null && body.note !== "") {
        if (typeof body.note !== "string" || body.note.length > 300) throw new HttpError(400, "note must be text up to 300 characters");
        note = body.note.trim();
      }
      const rows = loadRows(body.complaint_ids);
      if (rows.some((r) => r.status === "Pending")) throw new HttpError(409, "A crew must be assigned before the work can be completed.");
      const changed = rows.filter((r) => r.status !== "Restored");
      if (!changed.length) throw new HttpError(409, "This incident is already completed.");
      D.completeIncident(db, changed.map((r) => r.id), body.cause, note, req.user.sub);
      let notified = 0;
      for (const r of changed) if (notifyStatusChange(db, r, "Restored", log)) notified++;
      audit(req, "complete", { complaints: changed.length, cause: body.cause });
      broadcast("incidents-changed", { reason: "status" });
      return { updated: changed.length, notified };
    }],

    ["POST", /^\/api\/incidents\/reopen$/, async (req) => {
      need(req, ...STAFF);
      const rows = loadRows((await readJson(req)).complaint_ids);
      const changed = rows.filter((r) => r.status !== "Pending");
      D.reopenIncident(db, changed.map((r) => r.id));
      audit(req, "reopen", { complaints: changed.length });
      if (changed.length) broadcast("incidents-changed", { reason: "status" });
      return { updated: changed.length };
    }],

    ["GET", /^\/api\/metrics$/, async (req) => { need(req, ...STAFF); return computeMetrics(ctx); }],
    ["GET", /^\/api\/critical-sites$/, async (req) => { need(req, ...STAFF); return { sites: D.criticalSites(db) }; }],

    ["POST", /^\/api\/critical-sites$/, async (req) => {
      need(req, "admin");
      const body = await readJson(req);
      validateLocation(body);
      const name = text(body.name, "name", 100);
      const type = typeof body.type === "string" && body.type.trim() ? body.type.trim().slice(0, 40) : "critical";
      const id = D.addSite(db, { name, type, lat: body.lat, lng: body.lng });
      audit(req, "add_critical_site", { name });
      return { status: 201, body: { id, name, type, lat: body.lat, lng: body.lng } };
    }],

    ["GET", /^\/api\/notifications$/, async (req) => {
      need(req, ...STAFF);
      return {
        notifications: D.recentNotifications(db).map((n) => ({
          id: n.id, complaint_id: D.formatId(n.complaint_id), phone: maskPhone(n.phone), message: n.message, created_at: n.created_at, delivery: n.delivery,
        })),
      };
    }],

    ["GET", /^\/api\/audit$/, async (req) => { need(req, "admin"); return { entries: D.recentAudit(db) }; }],

    // ---------- sandbox bill (consumer logs in with RR number + last 4 digits of the registered phone) ----------
    ["POST", /^\/api\/consumer\/login$/, async (req) => {
      const body = await readJson(req);
      const rr = typeof body.rr === "string" ? body.rr.trim().toUpperCase() : "";
      const last4 = typeof body.last4 === "string" ? body.last4.trim() : "";
      if (!rr || rr.length > 30 || !/^\d{4}$/.test(last4)) throw new HttpError(400, "Enter your RR number and the last 4 digits of your registered phone");
      const key = ipOf(req) + "|" + rr;
      if (loginLimiter.blocked(key)) throw new HttpError(429, "Too many failed attempts. Try again in a few minutes.");
      const account = D.getAccount(db, rr);
      if (!account || String(account.phone).slice(-4) !== last4) {
        loginLimiter.hit(key);
        throw new HttpError(401, "RR number or code not recognised");
      }
      loginLimiter.clear(key);
      return { token: signToken({ sub: rr, role: "consumer" }, secret, consumerTtl), rr, name: account.name, expires_in: consumerTtl };
    }],

    ["GET", /^\/api\/consumer\/bill$/, async (req) => {
      need(req, "consumer");
      const account = D.getAccount(db, req.user.sub);
      if (!account) throw new HttpError(404, "Account not found");
      return {
        sandbox: true,
        note: "Sample account and sample tariff. Payments here are a sandbox: no money moves.",
        account: { rr: account.rr, name: account.name, address: account.address },
        bills: D.billsFor(db, account.rr).map((b) => ({
          id: b.id, month: b.month, units: b.units, amount: b.amount, due_date: b.due_date, status: b.status, paid_at: b.paid_at, paid_method: b.paid_method, receipt: b.receipt,
        })),
      };
    }],

    ["POST", /^\/api\/consumer\/pay$/, async (req) => {
      need(req, "consumer");
      const body = await readJson(req);
      if (!PAY_METHODS.includes(body.method)) throw new HttpError(400, "method must be one of: " + PAY_METHODS.join(", "));
      const bills = D.billsFor(db, req.user.sub);
      const bill = body.bill_id !== undefined ? bills.find((b) => b.id === body.bill_id) : bills.find((b) => b.status === "Unpaid");
      if (!bill) throw new HttpError(404, "Bill not found");
      if (bill.status === "Paid") throw new HttpError(409, "This bill is already paid");
      const receipt = "PAY-" + crypto.randomInt(100000, 1000000);
      D.markPaid(db, bill.id, body.method, receipt);
      audit(req, "sandbox_payment", { bill: bill.id, amount: bill.amount, method: body.method });
      return { sandbox: true, message: "Sandbox payment recorded. No money was charged.", receipt, amount: bill.amount, month: bill.month, method: body.method };
    }],

    // ---------- new connection applications ----------
    ["POST", /^\/api\/applications$/, async (req) => {
      if (!applicationLimiter.take(ipOf(req))) throw new HttpError(429, "Too many applications from this connection. Try again later.");
      const body = await readJson(req);
      const name = text(body.name, "name", 100);
      const address = text(body.address, "address", 300);
      const type = body.type ?? "Domestic";
      if (!["Domestic", "Commercial"].includes(type)) throw new HttpError(400, "type must be Domestic or Commercial");
      if (!isNum(body.load_kw) || body.load_kw <= 0 || body.load_kw > 50) throw new HttpError(400, "load_kw must be a number above 0 and up to 50");
      const phone = validatePhone(body.phone, true);
      const id = D.insertApplication(db, { name, address, type, load_kw: body.load_kw, phone });
      D.addAudit(db, "public", null, "application_submitted", JSON.stringify({ id }));
      return { status: 201, body: { ref: "APP-" + String(id).padStart(4, "0"), status: "Submitted" } };
    }],

    // Applicant checks status with the reference and the last 4 digits of the phone they entered.
    ["GET", /^\/api\/applications\/(APP-\d{1,9})$/i, async (req, m) => {
      const ref = m[1].toUpperCase();
      const last4 = new URL(req.url, "http://x").searchParams.get("last4") || "";
      const key = ipOf(req) + "|" + ref;
      if (lookupLimiter.blocked(key)) throw new HttpError(429, "Too many attempts. Try again in a few minutes.");
      const app = D.getApplication(db, parseInt(ref.slice(4), 10));
      if (!app || !/^\d{4}$/.test(last4) || app.phone.slice(-4) !== last4) {
        lookupLimiter.hit(key);
        throw new HttpError(404, "Application not found. Check the reference and the last 4 digits of your phone.");
      }
      return { ref, status: app.status, type: app.type, load_kw: app.load_kw, submitted_at: app.created_at, review_note: app.review_note };
    }],

    ["GET", /^\/api\/applications$/, async (req) => {
      need(req, "admin");
      return { applications: D.listApplications(db).map((a) => ({ ...a, ref: "APP-" + String(a.id).padStart(4, "0"), phone: maskPhone(a.phone) })) };
    }],

    ["POST", /^\/api\/applications\/(APP-\d{1,9})\/review$/i, async (req, m) => {
      need(req, "admin");
      const body = await readJson(req);
      if (!["Approved", "Rejected"].includes(body.decision)) throw new HttpError(400, "decision must be Approved or Rejected");
      let note = null;
      if (body.note !== undefined && body.note !== null && body.note !== "") note = text(body.note, "note", 300);
      const id = parseInt(m[1].toUpperCase().slice(4), 10);
      if (!D.getApplication(db, id)) throw new HttpError(404, "Application not found");
      if (D.reviewApplication(db, id, body.decision, note, req.user.sub).changes === 0) throw new HttpError(409, "This application was already reviewed");
      audit(req, "review_application", { id, decision: body.decision });
      return { ref: "APP-" + String(id).padStart(4, "0"), status: body.decision };
    }],

    // ---------- demo helpers (admin only, can be switched off with ALLOW_DEMO=false) ----------
    ["POST", /^\/api\/demo\/seed$/, async (req) => {
      need(req, "admin");
      if (!allowDemo) throw new HttpError(404, "Not found");
      const result = seedDemo(db);
      audit(req, "demo_seed", result);
      broadcast("incidents-changed", { reason: "seed" });
      return { message: "Demo data loaded", ...result };
    }],
    ["POST", /^\/api\/demo\/reset$/, async (req) => {
      need(req, "admin");
      if (!allowDemo) throw new HttpError(404, "Not found");
      D.resetAll(db);
      audit(req, "demo_reset");
      broadcast("incidents-changed", { reason: "reset" });
      return { message: "All complaints cleared" };
    }],
  ];

  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === "OPTIONS") {
        res.writeHead(204, CORS);
        return res.end();
      }
      const pathname = new URL(req.url, "http://localhost").pathname.replace(/\/+$/, "") || "/";
      const auth = /^Bearer (.+)$/.exec(req.headers.authorization || "");
      req.user = auth ? verifyToken(auth[1], secret) : null;

      if (req.method === "GET" && pathname === "/api/events") {
        if (clients.size >= 200) throw new HttpError(503, "Too many live connections");
        res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive", "X-Accel-Buffering": "no", ...CORS });
        res.write("retry: 3000\nevent: hello\ndata: {}\n\n");
        clients.add(res);
        req.on("close", () => clients.delete(res));
        return;
      }
      for (const [method, pattern, handler] of routes) {
        const m = pattern.exec(pathname);
        if (method === req.method && m) {
          const out = await handler(req, m);
          return out && out.body !== undefined && out.status ? send(res, out.status, out.body) : send(res, 200, out);
        }
      }
      throw new HttpError(404, "Not found");
    } catch (err) {
      if (err instanceof HttpError) return send(res, err.status, { error: err.message });
      log("Unexpected error:", err);
      return send(res, 500, { error: "Internal server error" });
    }
  });
  server.on("close", () => {
    clearInterval(heartbeat);
    for (const res of clients) res.end();
    clients.clear();
  });
  return server;
}

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [major, minor] = process.versions.node.split(".").map(Number);
  if (major < 22 || (major === 22 && minor < 13)) {
    console.error(`Node ${process.versions.node} is too old. LumenOps API needs Node 22.13 or newer (check: node -v).`);
    process.exit(1);
  }
  const port = Number(process.env.PORT) || 4000;
  const db = D.openDb();
  if (!process.env.AUTH_SECRET) console.log("[auth] No AUTH_SECRET set: a random one is used, so everyone has to log in again after a restart.");
  createApp({ db }).listen(port, () => {
    console.log(`LumenOps API running on http://localhost:${port}`);
    console.log(`ML service expected at ${process.env.ML_URL || "http://127.0.0.1:5001"}`);
    console.log("Sandbox billing account: RR-DEMO-1042, code 0042 (sample data)");
  });
}
