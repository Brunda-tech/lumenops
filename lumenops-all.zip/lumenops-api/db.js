// SQLite storage using Node's built-in node:sqlite (needs Node 22.13 or newer, no npm install).
import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";

export const STATUS_ORDER = ["Pending", "Crew assigned", "Restored"];

function ensureColumn(db, table, column, definition) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}

export function openDb(file = process.env.DB_PATH || "data/lumenops.db") {
  if (file !== ":memory:") fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec(`
    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      lat REAL NOT NULL,
      lng REAL NOT NULL,
      type TEXT NOT NULL DEFAULT 'no_power',
      phone TEXT,
      note TEXT,
      timestamp TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending',
      assigned_at TEXT,
      restored_at TEXT,
      crew TEXT,
      cause TEXT,
      resolution_note TEXT,
      assigned_by TEXT,
      completed_by TEXT
    );
    CREATE TABLE IF NOT EXISTS critical_sites (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'critical',
      lat REAL NOT NULL,
      lng REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      complaint_id INTEGER NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL,
      delivery TEXT NOT NULL DEFAULT 'queued'
    );
    CREATE TABLE IF NOT EXISTS users (
      username TEXT PRIMARY KEY,
      role TEXT NOT NULL,
      salt TEXT NOT NULL,
      hash TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      at TEXT NOT NULL,
      actor TEXT NOT NULL,
      role TEXT,
      action TEXT NOT NULL,
      details TEXT
    );
    CREATE TABLE IF NOT EXISTS consumer_accounts (
      rr TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      address TEXT NOT NULL,
      phone TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS bills (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rr TEXT NOT NULL,
      month TEXT NOT NULL,
      units INTEGER NOT NULL,
      amount INTEGER NOT NULL,
      due_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Unpaid',
      paid_at TEXT,
      paid_method TEXT,
      receipt TEXT
    );
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      address TEXT NOT NULL,
      type TEXT NOT NULL,
      load_kw REAL NOT NULL,
      phone TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Submitted',
      created_at TEXT NOT NULL,
      reviewed_by TEXT,
      reviewed_at TEXT,
      review_note TEXT
    );
  `);
  // Older database files made before these columns existed are upgraded in place.
  ensureColumn(db, "complaints", "assigned_at", "TEXT");
  ensureColumn(db, "complaints", "restored_at", "TEXT");
  for (const c of ["crew", "cause", "resolution_note", "assigned_by", "completed_by"]) ensureColumn(db, "complaints", c, "TEXT");
  ensureColumn(db, "notifications", "delivery", "TEXT NOT NULL DEFAULT 'queued'");
  return db;
}

// Complaint ids are shown as C0001, C0002, ...
export const formatId = (n) => "C" + String(n).padStart(4, "0");
export function parseId(s) {
  const m = /^C?(\d{1,9})$/i.exec(String(s));
  return m ? parseInt(m[1], 10) : null;
}

function tx(db, fn) {
  db.exec("BEGIN");
  try {
    const out = fn();
    db.exec("COMMIT");
    return out;
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

export function insertComplaint(db, c) {
  const r = db
    .prepare("INSERT INTO complaints (lat, lng, type, phone, note, timestamp, status) VALUES (?, ?, ?, ?, ?, ?, ?)")
    .run(c.lat, c.lng, c.type || "no_power", c.phone ?? null, c.note ?? null, c.timestamp, c.status || "Pending");
  return Number(r.lastInsertRowid);
}

export const allComplaints = (db) => db.prepare("SELECT * FROM complaints ORDER BY id").all();
export const getComplaint = (db, id) => db.prepare("SELECT * FROM complaints WHERE id = ?").get(id);
export const countComplaints = (db) => db.prepare("SELECT COUNT(*) AS n FROM complaints").get().n;

// Changes the status and keeps the times we need for the success metrics.
export function setStatus(db, ids, status) {
  if (!ids.length) return;
  const now = new Date().toISOString();
  let run;
  if (status === "Restored") {
    const stmt = db.prepare("UPDATE complaints SET status = ?, restored_at = ? WHERE id = ?");
    run = (id) => stmt.run(status, now, id);
  } else if (status === "Crew assigned") {
    const stmt = db.prepare("UPDATE complaints SET status = ?, assigned_at = ?, restored_at = NULL WHERE id = ?");
    run = (id) => stmt.run(status, now, id);
  } else {
    const stmt = db.prepare("UPDATE complaints SET status = ?, assigned_at = NULL, restored_at = NULL WHERE id = ?");
    run = (id) => stmt.run(status, id);
  }
  tx(db, () => ids.forEach(run));
}

export const criticalSites = (db) => db.prepare("SELECT id, name, type, lat, lng FROM critical_sites ORDER BY id").all();
export function addSite(db, s) {
  const r = db
    .prepare("INSERT INTO critical_sites (name, type, lat, lng) VALUES (?, ?, ?, ?)")
    .run(s.name, s.type || "critical", s.lat, s.lng);
  return Number(r.lastInsertRowid);
}

export function addNotification(db, complaintId, phone, message) {
  const r = db
    .prepare("INSERT INTO notifications (complaint_id, phone, message, created_at) VALUES (?, ?, ?, ?)")
    .run(complaintId, phone, message, new Date().toISOString());
  return Number(r.lastInsertRowid);
}
export const setDelivery = (db, id, delivery) =>
  db.prepare("UPDATE notifications SET delivery = ? WHERE id = ?").run(delivery, id);
export const recentNotifications = (db, limit = 50) =>
  db.prepare("SELECT * FROM notifications ORDER BY id DESC LIMIT ?").all(limit);
export function deliveryCounts(db) {
  const out = { queued: 0, stub: 0, sent: 0, failed: 0 };
  for (const r of db.prepare("SELECT delivery, COUNT(*) AS n FROM notifications GROUP BY delivery").all()) out[r.delivery] = r.n;
  return out;
}

export function resetAll(db) {
  tx(db, () => {
    db.exec("DELETE FROM complaints; DELETE FROM critical_sites; DELETE FROM notifications;");
    db.exec("DELETE FROM sqlite_sequence WHERE name IN ('complaints','critical_sites','notifications');");
  });
}

export function insertMany(db, complaints, sites) {
  tx(db, () => {
    complaints.forEach((c) => insertComplaint(db, c));
    sites.forEach((s) => addSite(db, s));
  });
}

// ---- crew assignment and completion (who did what is stored on the complaint) ----
export function assignCrew(db, ids, crew, actor) {
  if (!ids.length) return;
  const now = new Date().toISOString();
  const stmt = db.prepare(
    "UPDATE complaints SET status = 'Crew assigned', crew = ?, assigned_by = ?, assigned_at = ?, restored_at = NULL, cause = NULL, resolution_note = NULL, completed_by = NULL WHERE id = ?"
  );
  tx(db, () => ids.forEach((id) => stmt.run(crew ?? null, actor, now, id)));
}

export function completeIncident(db, ids, cause, note, actor) {
  if (!ids.length) return;
  const now = new Date().toISOString();
  const stmt = db.prepare(
    "UPDATE complaints SET status = 'Restored', restored_at = ?, cause = ?, resolution_note = ?, completed_by = ? WHERE id = ?"
  );
  tx(db, () => ids.forEach((id) => stmt.run(now, cause, note ?? null, actor, id)));
}

export function reopenIncident(db, ids) {
  if (!ids.length) return;
  const stmt = db.prepare(
    "UPDATE complaints SET status = 'Pending', crew = NULL, assigned_by = NULL, assigned_at = NULL, restored_at = NULL, cause = NULL, resolution_note = NULL, completed_by = NULL WHERE id = ?"
  );
  tx(db, () => ids.forEach((id) => stmt.run(id)));
}

// ---- staff accounts and activity log ----
export const getUser = (db, username) => db.prepare("SELECT * FROM users WHERE username = ?").get(username);
export const upsertUser = (db, username, role, salt, hash) =>
  db
    .prepare("INSERT INTO users (username, role, salt, hash) VALUES (?, ?, ?, ?) ON CONFLICT(username) DO UPDATE SET role = excluded.role, salt = excluded.salt, hash = excluded.hash")
    .run(username, role, salt, hash);

export function addAudit(db, actor, role, action, details = "") {
  db.prepare("INSERT INTO audit_log (at, actor, role, action, details) VALUES (?, ?, ?, ?, ?)")
    .run(new Date().toISOString(), actor, role ?? null, action, details);
}
export const recentAudit = (db, limit = 100) => db.prepare("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?").all(limit);

// ---- sandbox billing ----
export const countAccounts = (db) => db.prepare("SELECT COUNT(*) AS n FROM consumer_accounts").get().n;
export const getAccount = (db, rr) => db.prepare("SELECT * FROM consumer_accounts WHERE rr = ?").get(rr);
export const insertAccount = (db, a) =>
  db.prepare("INSERT INTO consumer_accounts (rr, name, address, phone) VALUES (?, ?, ?, ?)").run(a.rr, a.name, a.address, a.phone);
export const insertBill = (db, b) =>
  db
    .prepare("INSERT INTO bills (rr, month, units, amount, due_date, status, paid_at, paid_method, receipt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
    .run(b.rr, b.month, b.units, b.amount, b.due_date, b.status || "Unpaid", b.paid_at ?? null, b.paid_method ?? null, b.receipt ?? null);
export const billsFor = (db, rr) => db.prepare("SELECT * FROM bills WHERE rr = ? ORDER BY month DESC").all(rr);
export const getBill = (db, id) => db.prepare("SELECT * FROM bills WHERE id = ?").get(id);
export const markPaid = (db, id, method, receipt) =>
  db.prepare("UPDATE bills SET status = 'Paid', paid_at = ?, paid_method = ?, receipt = ? WHERE id = ? AND status = 'Unpaid'")
    .run(new Date().toISOString(), method, receipt, id);

// ---- new connection applications ----
export function insertApplication(db, a) {
  const r = db
    .prepare("INSERT INTO applications (name, address, type, load_kw, phone, created_at) VALUES (?, ?, ?, ?, ?, ?)")
    .run(a.name, a.address, a.type, a.load_kw, a.phone, new Date().toISOString());
  return Number(r.lastInsertRowid);
}
export const getApplication = (db, id) => db.prepare("SELECT * FROM applications WHERE id = ?").get(id);
export const listApplications = (db) => db.prepare("SELECT * FROM applications ORDER BY id DESC LIMIT 200").all();
export const reviewApplication = (db, id, status, note, actor) =>
  db
    .prepare("UPDATE applications SET status = ?, review_note = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ? AND status = 'Submitted'")
    .run(status, note ?? null, actor, new Date().toISOString(), id);
