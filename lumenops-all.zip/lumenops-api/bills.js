// SANDBOX billing. The account, usage and amounts are made up. The tariff is NOT BESCOM's real tariff.
import { countAccounts, insertAccount, insertBill } from "./db.js";

export const SAMPLE_RR = "RR-DEMO-1042";
export const SAMPLE_LAST4 = "0042";
export const TARIFF_NOTE = "Sample tariff for the demo, not BESCOM's real rates";

// 60 fixed + 4 per unit for the first 50, 5.5 for the next 50, 7 above 100.
export const tariff = (u) => Math.round(60 + Math.min(u, 50) * 4 + Math.max(Math.min(u - 50, 50), 0) * 5.5 + Math.max(u - 100, 0) * 7);

export function seedSampleBilling(db) {
  if (countAccounts(db) > 0) return false;
  insertAccount(db, { rr: SAMPLE_RR, name: "Sample Consumer", address: "Sample Street, Bengaluru", phone: "91000000" + SAMPLE_LAST4 });
  const units = [118, 126, 141, 152, 133, 127];
  const now = new Date();
  units.forEach((u, i) => {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - (units.length - 1 - i), 1));
    const month = d.toISOString().slice(0, 7);
    const latest = i === units.length - 1;
    insertBill(db, {
      rr: SAMPLE_RR, month, units: u, amount: tariff(u), due_date: month + "-28",
      status: latest ? "Unpaid" : "Paid",
      paid_at: latest ? null : month + "-20T10:00:00.000Z", paid_method: latest ? null : "UPI", receipt: latest ? null : "PAY-SAMPLE-" + (i + 1),
    });
  });
  return true;
}
