// Small client for the Flask ML service.
export class MlError extends Error {}

export async function analyze(mlUrl, complaints, criticalSites, now) {
  let res;
  try {
    res = await fetch(mlUrl.replace(/\/$/, "") + "/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ complaints, critical_sites: criticalSites, now }),
      signal: AbortSignal.timeout(5000),
    });
  } catch (err) {
    throw new MlError("Cannot reach the ML service at " + mlUrl + " (" + (err.cause?.code || err.message) + ")");
  }
  if (!res.ok) throw new MlError("ML service returned HTTP " + res.status);
  try {
    return await res.json();
  } catch {
    throw new MlError("ML service sent an invalid response");
  }
}

export async function mlHealth(mlUrl) {
  try {
    const res = await fetch(mlUrl.replace(/\/$/, "") + "/health", { signal: AbortSignal.timeout(2000) });
    return res.ok;
  } catch {
    return false;
  }
}
