// SMS notifications.
// Default: STUB. The message is saved and printed, nothing is really sent.
// Real SMS: set SMS_WEBHOOK_URL (and optionally SMS_WEBHOOK_TOKEN). For every message we POST JSON
//   { "to": "<digits>", "message": "<text>" }   with   Authorization: Bearer <token>
// to that URL. Point it at your SMS provider or a small adapter that calls the provider.
import { addNotification, formatId, setDelivery } from "./db.js";

const MESSAGES = {
  "Crew assigned": (ref) => `LumenOps: A crew has been assigned to the outage you reported (ref ${ref}).`,
  Restored: (ref) =>
    `LumenOps: Power is reported restored in your area (ref ${ref}). If it is still out, please report again.`,
};

export const maskPhone = (p) => "******" + String(p).slice(-4);

async function sendSms(phone, message, log) {
  const url = process.env.SMS_WEBHOOK_URL;
  if (!url) {
    log(`[SMS stub] to ${maskPhone(phone)}: ${message}`);
    return "stub";
  }
  const headers = { "Content-Type": "application/json" };
  if (process.env.SMS_WEBHOOK_TOKEN) headers.Authorization = "Bearer " + process.env.SMS_WEBHOOK_TOKEN;
  const res = await fetch(url, {
    method: "POST",
    headers,
    body: JSON.stringify({ to: phone, message }),
    signal: AbortSignal.timeout(5000),
  });
  if (!res.ok) throw new Error("SMS provider returned HTTP " + res.status);
  log(`[SMS sent] to ${maskPhone(phone)}`);
  return "sent";
}

// Saves the message, then sends it in the background so the API answer is not delayed.
export function notifyStatusChange(db, complaint, status, log = console.log) {
  const make = MESSAGES[status];
  if (!make || !complaint.phone) return false;
  const message = make(formatId(complaint.id));
  const id = addNotification(db, complaint.id, complaint.phone, message);
  sendSms(complaint.phone, message, log)
    .then((delivery) => setDelivery(db, id, delivery))
    .catch((err) => {
      log(`[SMS failed] to ${maskPhone(complaint.phone)}: ${err.message}`);
      try {
        setDelivery(db, id, "failed");
      } catch {
        /* database already closed */
      }
    });
  return true;
}
